
package test;

import test.TestTask;

import bali.core.Application;
import bali.core.Archive;
import bali.core.Task;
import bali.core.CriticalException;

import java.io.IOException;
/*
 *
 * TestApp
 *
 */
public final class TestApp extends Application
{
    static TestApp thisApp;
    TestTask task1;

    public TestApp( Object parent, String name)
        throws CriticalException, IOException
    {
		super( parent, name);
    }

    public void create( String args[] ) throws Throwable
	{
		super.create( args );
		task1 = new TestTask( this, "Test1" );
	}

	public void start()
	{
        // Called by main after create()

        task1.start();      //Start executing Task.

	}

    public static void main( String args[] ) throws Throwable
    {
        try
        {
            thisApp = new TestApp( null, "TestApp" );
            thisApp.create( args );
            thisApp.start();
        }
        catch( Throwable e )
        {
            System.out.println( "Exception thrown. Caught in main().\n" + e );
            e.printStackTrace();
        }
    }

    public void coldStart() throws Throwable
    {
        // Called by the Framework when -COLD is given on the
        // command line
        // At this point the Task has not yet been created.

    }

    public void warmStart() throws Throwable
    {
        // Called by the Framework when -WARM is given on the
        // command line
        // At this point the Task has not yet been created.
    }

    public void coolStart() throws Throwable
    {
        // Called by the Framework when neither -WARM nor -COLD
        // is given on the command line
        // At this point the Task has not yet been created.
    }

    public String fromString( String expr )
    {
        return "";
    }

    public String toString()
    {
        return "";
    }
}

