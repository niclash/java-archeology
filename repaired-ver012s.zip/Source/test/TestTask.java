
package test;

import java.io.IOException;
import java.awt.Graphics;

import bali.core.Task;
import bali.core.Archive;
import bali.core.Application;
import bali.core.GlobalBool;
import bali.core.GlobalChar;
import bali.core.GlobalDouble;
import bali.core.GlobalFloat;
import bali.core.GlobalInt;
import bali.core.GlobalLong;
import bali.core.GlobalShort;
import bali.core.GlobalString;

import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

/*
 *
 * TestTask
 *
 */

public class TestTask extends Task
{
    GlobalDouble m_Double;
    GlobalFloat m_Float;
    GlobalBool m_Bool;
    GlobalChar m_Char;
    GlobalInt m_Int;
    GlobalLong m_Long;
    GlobalShort m_Short;
    GlobalString m_String;

    public TestTask( Application parent, String Name )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        super( parent, Name );
        m_Bool = new GlobalBool( this, "Boolean" );
        m_Char = new GlobalChar( this, "Char" );
        m_Double = new GlobalDouble( this, "Double" );
        m_Float = new GlobalFloat( this, "Float" );
        m_Int = new GlobalInt( this, "Integer" );
        m_Long = new GlobalLong( this, "Long" );
        m_Short = new GlobalShort( this, "Short" );
        m_String = new GlobalString( this, "String" );
        m_Double.set( 1 );
        m_Float.set( 0.1f );
        m_Char.set( 'B' );
    }

    public boolean onTimer()
        throws IOException, ObjectReadOnlyException
    {
        m_Bool.set( ! m_Bool.get() );
        m_Int.set( m_Int.get() * m_Short.get() + 1 );
        m_Double.set( m_Double.get() * m_Float.get() );
        m_Float.set( m_Float.get() + 0.1f );
        m_Long.set( System.currentTimeMillis() );
        m_String.set( m_String.get() + m_Char.get() );
        m_Short.set( (short) (m_Short.get() + 1) );

        switch( m_Char.get() )
        {
        case 'B':
            m_Char.set( 'a' );
            break;
        case 'a':
            m_Char.set( 'l' );
            break;
        case 'l':
            m_Char.set( 'i' );
            break;
        case 'i':
            m_Char.set( ' ' );
            break;
        case ' ':
            m_Char.set( 'C' );
            break;
        case 'C':
            m_Char.set( 'o' );
            break;
        case 'o':
            m_Char.set( 'r' );
            break;
        case 'r':
            m_Char.set( 'e' );
            break;
        case 'e':
            m_Char.set( '.' );
            break;
        case '.':
            m_Char.set( '{' );
            break;
        case '{':
            m_Char.set( '�' );
            break;
        case '�':
            m_Char.set( '}' );
            break;
        case '}':
            m_Char.set( 'B' );
            break;
        default:
            m_Char.set( 'B' );
        }
        return true;
    }

    public void coldStart()
    {
        // Called by the Framework when -COLD is given on the
        // command line
    }

    public void warmStart()
    {
        // Called by the Framework when -WARM is given on the
        // command line
    }

    public void coolStart()
    {
        // Called by the Framework when neither -WARM nor -COLD
        // is given on the command line
    }

    public boolean onViewCreate( Graphics g, long flags )
    {
        return true;
    }

    public boolean onViewUpdate( Graphics g, long flags )
    {
        return false;
    }

    public String fromString( String expr )
    {
        return "";
    }

    public String toString()
    {
        return "";
    }
}

