// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.util.Enumeration;
import jgl.ArrayAdapter;
import jgl.ForwardIterator;
import jgl.Comparing;
import jgl.Printing;
import jgl.InvalidOperationException;
import jgl.CharIterator;

/**
 * CharArray allows a native array of chars to be accessed like a Container.
 * It is particularly useful for applying generic algorithms like Sorting.sort()
 * to a native array.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public class CharArray extends ArrayAdapter
  {
  char myArray[];

  public CharArray( char array[] )
    {
    myArray = array;
    }

  public CharArray( CharArray array )
    {
    myArray = array.myArray;
    }

  /**
   * Return a shallow copy of myself.
   */
  public Object clone()
    {
    return new CharArray( this );
    }

  /**
   * Return a string that describes me.
   */
  public String toString()
    {
    return Printing.toString( this, "char[]" );
    }

  /**
   * Return true if I'm equal to a specified object.
   * @param object The object to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public boolean equals( Object object )
    {
    return Comparing.equal( this, (CharArray) object );
    }
  
  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return myArray.length;
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return myArray.length;
    }

  /**
   * Return an Enumeration of my components.
   */
  public Enumeration elements()
    {
    return CharIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public ForwardIterator start()
    {
    return CharIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public ForwardIterator finish()
    {
    return CharIterator.end( myArray, this );
    }

  /**
   * Return the integer at the specified index as a Character object.
   * @param index The index.
   */
  public Object at( int index )
    {
    return new Character( myArray[index] );
    }

  /**
   * Set the object at a specified index.  The object must be a Character
   * @param index The index.
   * @param object The object to place at the specified index.
   * @exception java.lang.ClassCastException if object is not a Character
   * @exception java.lang.IndexOutOfBoundsException if object is not a Character
   */
  public void put( int index, Object object )
    {
    myArray[index] = ((Character)object).charValue();
    }
  }
