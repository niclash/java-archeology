// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.io.OutputStream;
import java.io.IOException;
import jgl.OutputIterator;

/**
 * An OutputStreamIterator is an output iterator that prints objects that are written
 * to it. By default, it writes to the standard output stream System.out.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public class OutputStreamIterator implements OutputIterator
  {
  OutputStream myStream;

  /**
   * Construct myself to print all objects to the standard output stream, System.out.
   */
  public OutputStreamIterator()
    {
    myStream = System.out;
    }

  /**
   * Construct myself to print all objects to the specified PrintStream.
   * @param stream The PrintStream.
   */
  public OutputStreamIterator( OutputStream stream )
    {
    myStream = stream;
    }

  /**
   * Construct myself to be associated with the same PrintStream as the specified iterator.
   */
  public OutputStreamIterator( OutputStreamIterator iterator )
    {
    myStream = iterator.myStream;
    }

  /**
   * Print the object to my OutputStream.
   * @param object The object.
   */
  public void put( Object object )
    {
    String s = (object == null ? "null" : object.toString() );
    int len = s.length();

    try
      {
      for( int i = 0 ; i < len ; i++ ) 
        myStream.write( s.charAt( i ) );

      myStream.write( ' ' );
      }
    catch( IOException exception )
      {
      System.err.println( "Caught exception " + exception );
      }
    }

  /**
   * Advance by one. This has no effect for an OutputStreamIterator.
   */
  public void advance()
    {
    // Do nothing.
    }

  /**
   * Advance by a specified amount. This has no effect for a OutputStreamIterator.
   * @param n The amount to advance.
   */
  public void advance( int n )
    {
    // Do nothing.
    }

  /**
   * Return a clone of myself.
   */
  public Object clone()
    {
    return new OutputStreamIterator( this );
    }
  }