// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BidirectionalIterator;
import jgl.Reversing;
import jgl.Swapping;
import jgl.BinaryPredicate;
import jgl.Container;

/**
 * The Permuting class contains generic permuting algorithms.
 * <p>
 * @see jgl.examples.PermutingExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Permuting
  {
  private Permuting()
    {
    }

  /**
   * Arrange a sequence to become its next permutation. If it was already the last 
   * permutation, become the first permutation. Logically, the entire set of permutations 
   * is lexicographically ordered using a comparitor.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   * @return true unless the sequence was already the last permutation.
   */
  public static boolean nextPermutation( BidirectionalIterator first, BidirectionalIterator last, BinaryPredicate comparitor )
    {
    if ( !(first.getContainer() instanceof Sequence) )
      throw new IllegalArgumentException( "iterator containers must be a Sequence" );

    if ( first.getContainer() != last.getContainer() )
      throw new IllegalArgumentException( "iterator containers must be the same" );
    
    if( first.equals( last ) )
      return false;

    BidirectionalIterator i = (BidirectionalIterator) first.clone();
    i.advance();

    if( i.equals( last ) )
      return false;

    i = (BidirectionalIterator) last.clone();
    i.retreat();

    while( true )
      {
      BidirectionalIterator ii = (BidirectionalIterator) i.clone();
      i.retreat();

      if( comparitor.execute( i.get(), ii.get() ) )
        {
        BidirectionalIterator j = (BidirectionalIterator) last.clone();
        j.retreat();

        while( !comparitor.execute( i.get(), j.get() ) )
          j.retreat();

        Swapping.iterSwap( i, j );
        Reversing.reverse( ii, last );
        return true;
        }

      if( i.equals( first ) )
        {
        Reversing.reverse( first, last );
        return false;
        }
      }
    }

  /**
   * Arrange a container to become its next permutation. If the container is already the 
   * last permutation, become the first permutation. Logically, the entire set of 
   * permutations is lexicographically ordered using a comparitor.
   * @param container The container.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   * @return true unless the container was already the last permutation.
   */
  public static boolean nextPermutation( Container container, BinaryPredicate comparitor )
    {
    return nextPermutation( (BidirectionalIterator) container.start(), (BidirectionalIterator) container.finish(), comparitor );
    }

  /**
   * Arrange a sequence to become its previous permutation. If it was already the first 
   * permutation, become the last permutation. Logically, the entire set of permutations 
   * is lexicographically ordered using a comparitor.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   * @return true unless the sequence was already the first permutation.
   */
  public static boolean prevPermutation( BidirectionalIterator first, BidirectionalIterator last, BinaryPredicate comparitor )
    {
    if ( !(first.getContainer() instanceof Sequence) )
      throw new IllegalArgumentException( "iterator containers must be a Sequence" );

    if ( first.getContainer() != last.getContainer() )
      throw new IllegalArgumentException( "iterator containers must be the same" );

    if( first.equals( last ) )
      return false;

    BidirectionalIterator i = (BidirectionalIterator) first.clone();
    i.advance();

    if( i.equals( last ) )
      return false;

    i = (BidirectionalIterator) last.clone();
    i.retreat();

    while( true )
      {
      BidirectionalIterator ii = (BidirectionalIterator) i.clone();
      i.retreat();

      if( comparitor.execute( ii.get(), i.get() ) )
        {
        BidirectionalIterator j = (BidirectionalIterator) last.clone();
        j.retreat();

        while( !comparitor.execute( j.get(), i.get() ) ) 
          j.retreat();

        Swapping.iterSwap( i, j );
        Reversing.reverse( ii, last );
        return true;
        }

      if( i.equals( first ) )
        {
        Reversing.reverse( first, last );
        return false;
        }
      }
    }

  /**
   * Arrange a container to become its previous permutation. If it was already the first 
   * permutation, become the last permutation. Logically, the entire set of permutations 
   * is lexicographically ordered using a comparitor.
   * @param container The container.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   * @return true unless the container was already the first permutation.
   */
  public static boolean prevPermutation( Container container, BinaryPredicate comparitor )
    {
    return prevPermutation( (BidirectionalIterator) container.start(), (BidirectionalIterator) container.finish(), comparitor );
    }
  }
