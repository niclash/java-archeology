// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.RandomAccessIterator;
import jgl.BooleanArray;

/**
 * An BooleanIterator is a random access iterator that allows you to iterate through
 * an array of booleans.
 * <p>
 * @see jgl.RandomAccessIterator
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class BooleanIterator implements RandomAccessIterator
  {
  BooleanArray myBooleanArray;
  boolean[] myArray;
  int myIndex;
  
  /**
   * Return an iterator positioned at the first element of a particular array.  
   * @param array The array whose first element I will be positioned at.
   */
  public static BooleanIterator begin( boolean[] array ) 
    {
    return new BooleanIterator( array, 0, new BooleanArray( array ) );
    }

  /**
   * Return an iterator positioned at the first element of a particular array.  
   * @param array The array whose first element I will be positioned at.
   * @param booleanArray The array I am iterating over.
   */
  public static BooleanIterator begin( boolean[] array, BooleanArray booleanArray ) 
    {
    return new BooleanIterator( array, 0, booleanArray );
    }

  /**
   * Return an iterator positioned immediately after the last element of a particular array.
   * @param array The array whose last element I will be positioned after.
   */
  public static BooleanIterator end( boolean[] array )
    {
    return new BooleanIterator( array, array.length, new BooleanArray( array ) );
    }

  /**
   * Return an iterator positioned immediately after the last element of a particular array.
   * @param array The array whose last element I will be positioned after.
   * @param booleanArray The array I am iterating over.
   */
  public static BooleanIterator end( boolean[] array, BooleanArray booleanArray )
    {
    return new BooleanIterator( array, array.length, booleanArray );
    }

  /**
   * Construct myself to be an iterator with no associated data structure or position.
   */
  public BooleanIterator()
    {
    }

  /**
   * Construct myself to be positioned at a particular index of a specific array.
   * @param array My associated array.
   * @param index My associated index.
   */
  public BooleanIterator( boolean[] array, int index )
    {
    myBooleanArray = new BooleanArray( array );
    myArray = array;
    myIndex = index;
    }

  /**
   * Construct myself to be positioned at a particular index of a specific array.
   * @param array My associated array.
   * @param index My associated index.
   * @param booleanArray The array I am iterating over.
   */
  public BooleanIterator( boolean[] array, int index, BooleanArray booleanArray )
    {
    myBooleanArray = booleanArray;
    myArray = array;
    myIndex = index;
    }

  /**
   * Construct myself to be a copy of an existing iterator.
   * @param iterator The iterator to copy.
   */
  public BooleanIterator( BooleanIterator iterator )
    {
    myBooleanArray = iterator.myBooleanArray;
    myArray = iterator.myArray;
    myIndex = iterator.myIndex;
    }

  /**
   * Return a clone of myself.
   */
  public Object clone()
    {
    return new BooleanIterator( this );
    }

  /**
   * Return my current index.
   */
  public int index()
    {
    return myIndex;
    }

  /**
   * Return true if a specified object is the same kind of iterator as me 
   * and is positioned at the same element.
   * @param object Any object.
   */
  public boolean equals( Object object )
    {
    return object instanceof BooleanIterator && equals( (BooleanIterator) object );
    }

  /**
   * Return true if iterator is positioned at the same element as me.
   * @param iterator The iterator to compare myself against.
   */
  public boolean equals( BooleanIterator iterator )
    {
    return iterator.myIndex == myIndex && iterator.myArray == myArray;
    }

  /**
   * Return true if I'm before a specified iterator.
   * @param iterator The iterator to compare myself against.
   */
  public boolean less( RandomAccessIterator iterator )
    {
    return myIndex < ((BooleanIterator) iterator).myIndex;
    }

  /**
   * Return the object that is a specified distance from my current position.
   * @param offset The offset from my current position.
   */
  public Object get( int offset )
    {
    return myArray[ myIndex + offset ] ? Boolean.TRUE : Boolean.FALSE;
    }

  /**
   * Write an object at a specified distance from my current position.
   * @param offset The offset from my current position.
   * @param object The object to write.
   */
  public void put( int offset, Object object )
    {
    myArray[ myIndex + offset ] = ((Boolean) object).booleanValue();
    }

  /**
   * Return true if I'm positioned at the first item of my input stream.
   */
  public boolean atBegin()
    {
    return myIndex == 0;
    }

  /**
   * Return true if I'm positioned after the last item in my input stream.
   */
  public boolean atEnd()
    {
    return myIndex == myArray.length;
    }

  /**
   * Return true if there are more elements in my input stream.
   */
  public boolean hasMoreElements()
    {
    return myIndex < myArray.length;
    }

  /**
   * Advance by one.
   */
  public void advance()
    {
    myIndex++;
    }

  /**
   * Advance by a specified amount.
   * @param n The amount to advance.
   */
  public void advance( int n )
    {
    myIndex += n;
    }

  /**
   * Retreat by one.
   */
  public void retreat()
    {
    myIndex--;
    }

  /**
   * Retreat by a specified amount.
   * @param n The amount to retreat.
   */
  public void retreat( int n )
    {
    myIndex -= n;
    }

  /**
   * Return the next element in my input stream.
   */
  public Object nextElement()
    {
    return new Boolean( myArray[ myIndex++ ] );
    }

  /**
   * Return the object at my current position.
   */
  public Object get()
    {
    return new Boolean( myArray[ myIndex ] );
    }

  /**
   * Set the object at my current position to a specified value.
   * @param object The object to be written at my current position.
   */
  public void put( Object object )
    {
    myArray[ myIndex ] = ((Boolean) object).booleanValue();
    }

  /**
   * Return the distance from myself to another iterator.
   * I should be before the specified iterator.
   * @param iterator The iterator to compare myself against.
   */
  public int distance( ForwardIterator iterator )
    {
    return ((BooleanIterator) iterator).myIndex - myIndex;
    }

  /** 
   * Return my associated container.
   */
  public Container getContainer() 
    {
    return myBooleanArray;
    }
  }
