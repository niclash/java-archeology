// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryFunction;

/**
 * LengthString is a unary function that returns the length of its String operand.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class LengthString implements UnaryFunction
  {
  /**
   * Return the length of my String operand as an Integer.
   * @param object The operand, which must be a String.
   * @return The length of the String operand.
   */
  public Object execute( Object object )
    {
    return new Integer( ((String) object).length() );
    }
  }