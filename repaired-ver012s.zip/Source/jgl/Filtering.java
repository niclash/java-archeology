// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.ForwardIterator;
import jgl.InputIterator;
import jgl.OutputIterator;
import jgl.InsertIterator;
import jgl.Finding;
import jgl.Container;
import jgl.EqualTo;
import jgl.BinaryPredicate;

/**
 * The Filtering class contains generic filtering algorithms.
 * <p>
 * @see jgl.examples.FilteringExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Filtering
  {
  private Filtering()
    {
    }

  /**
   * Replace all consecutive occurrences of an object in a sequence by a single
   * instance of that object. Use equals() to perform the equality test. The size of the 
   * sequence is not altered; if n elements are removed, the last n elements will have 
   * undefined values. The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @return An iterator positioned immediately after the last element of the "new" sequence.
   */
  public static ForwardIterator unique( ForwardIterator first, ForwardIterator last )
    {
    return unique( first, last, new EqualTo() );
    }

  /**
   * Replace all consecutive occurrences of an object in a container by a single
   * instance of that object. Use equals() to perform the equality test. The size of the 
   * container is not altered; if n elements are removed, the last n elements will have 
   * undefined values. The time complexity is linear and the space complexity is constant.
   * @param container The container.
   * @return An iterator positioned immediately after the last element of the "new" sequence.
   */
  public static ForwardIterator unique( Container container )
    {
    return unique( container.start(), container.finish(), new EqualTo() );
    }

  /**
   * Replace all consecutive occurrences of an object in a sequence by a single
   * instance of that object. The size of the sequence is not altered; if n elements are
   * removed, the last n elements will have undefined values. The time complexity is 
   * linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param predicate A BinaryPredicate that returns true if both of its operands are "equal". 
   * @return An iterator positioned immediately after the last element of the new sequence.
   */
  public static ForwardIterator unique( ForwardIterator first, ForwardIterator last, BinaryPredicate predicate )
    {
    first = (ForwardIterator) Finding.adjacentFind( first, last, predicate );
    return (ForwardIterator) uniqueCopy( first, last, first, predicate );
    }

  /**
   * Replace all consecutive occurrences of an object in a container by a single
   * instance of that object. The size of the container is not altered; if n elements are
   * removed, the last n elements will have undefined values. The time complexity is 
   * linear and the space complexity is constant.
   * @param container The container.
   * @param predicate A binary predicate that returns true if both of its operands are "equal". 
   * @return An iterator positioned immediately after the last element of the "new" sequence.
   */
  public static ForwardIterator unique( Container container, BinaryPredicate predicate )
    {
    return unique( container.start(), container.finish(), predicate );
    }

  /**
   * Copy a sequence into another sequence, replacing all consecutive occurrences of an 
   * object by a single instance of that object. Use equals() to perform the equality test.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the input sequence.
   * @param last An iterator positioned immediately after the last element of the input sequence.
   * @param result An iterator positioned at the first element of the output sequence.
   * @return An iterator positioned immediately after the last element of the output sequence.
   */
  public static OutputIterator uniqueCopy( InputIterator first, InputIterator last, OutputIterator result )
    {
    return uniqueCopy( first, last, result, new EqualTo() );
    }

  /**
   * Copy a container into another sequence, replacing all consecutive occurrences of an 
   * object by a single instance of that object. Use equals() to perform the equality test.
   * The time complexity is linear and the space complexity is constant.
   * @param container The container.
   * @param result An iterator positioned at the first element of the output sequence.
   * @return An iterator positioned immediately after the last element of the output sequence.
   */
  public static OutputIterator uniqueCopy( Container container, OutputIterator result )
    {
    return uniqueCopy( container.start(), container.finish(), result, new EqualTo() );
    }

  /**
   * Copy the contents of one container into another container, replacing all consecutive 
   * occurrences of an object by a single instance of that object. Use equals() to perform 
   * the equality test. The time complexity is linear and the space complexity is constant.
   * @param source The source container.
   * @param destination The destination container.
   */
  public static void uniqueCopy( Container source, Container destination )
    {
    uniqueCopy( source.start(), source.finish(), new InsertIterator( destination ), new EqualTo() );
    }

  /**
   * Copy a sequence into another sequence, replacing all consecutive occurrences of an 
   * object by a single instance of that object. The time complexity is linear and the 
   * space complexity is constant.
   * @param first An iterator positioned at the first element of the input sequence.
   * @param last An iterator positioned immediately after the last element of the input sequence.
   * @param result An iterator positioned at the first element of the output sequence.
   * @param predicate A binary predicate that returns true if both of its operands are "equal". 
   * @return An iterator positioned immediately after the last element of the output sequence.
   */
  public static OutputIterator uniqueCopy( InputIterator first, InputIterator last, OutputIterator result, BinaryPredicate predicate )
    {
    if( first.equals( last ) )
      {
      return (OutputIterator) result.clone();
      }
    else if( result instanceof ForwardIterator )
      {
      ForwardIterator resultx = (ForwardIterator) result.clone();
      InputIterator firstx = (InputIterator) first.clone();
      resultx.put( firstx.nextElement() );

      while( !firstx.equals( last ) )
        {
        if( !predicate.execute( resultx.get(), firstx.get() ) )
          {
          resultx.advance();
          resultx.put( firstx.get() );
          }

        firstx.advance();        
        }

      resultx.advance();
      return resultx;
      }
    else
      {
      OutputIterator resultx = (OutputIterator) result.clone();
      InputIterator firstx = (InputIterator) first.clone(); 
      Object value = firstx.get();
      resultx.put( value );
      firstx.advance();

      while( !firstx.equals( last ) )
        {
        if( !predicate.execute( value, firstx.get() ) )
          {
          value = firstx.get();
          resultx.advance();
          resultx.put( value );
          }

        firstx.advance();
        }

      resultx.advance();
      return resultx;
      }
    }

  /**
   * Copy a container into another sequence, replacing all consecutive occurrences of an 
   * object by a single instance of that object. The time complexity is linear and the 
   * space complexity is constant.
   * @param container A container.
   * @param result An iterator positioned at the first element of the output sequence.
   * @param predicate A binary predicate that returns true if both of its operands are "equal". 
   * @return An iterator positioned immediately after the last element of the output sequence.
   */
  public static OutputIterator uniqueCopy( Container container, OutputIterator result, BinaryPredicate predicate )
    {
    return uniqueCopy( container.start(), container.finish(), result, predicate );
    }

  /**
   * Copy the contents of one container into another container, replacing all consecutive 
   * occurrences of an object by a single instance of that object. The time complexity is 
   * linear and the space complexity is constant.
   * @param source The source container.
   * @param destination The destination container.
   * @param predicate A binary predicate that returns true if both of its operands are "equal". 
   */
  public static void uniqueCopy( Container source, Container destination, BinaryPredicate predicate )
    {
    uniqueCopy( source.start(), source.finish(), new InsertIterator( destination ), predicate );
    }
  }
