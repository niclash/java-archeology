// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BinaryPredicate;

/**
 * LogicalOr is a binary predicate that returns true if either operand is equal to 
 * Boolean.TRUE.
 * <p>
 * @see jgl.LogicalAnd
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class LogicalOr implements BinaryPredicate
  {
  /**
   * Perform a logical OR.
   * @param first The first operand, which must be an instance of Boolean.
   * @param second The second operand, which must be an instance of Boolean.
   * @return true if either operand is equal to Boolean.TRUE.
   */
  public boolean execute( Object first, Object second )
    {
    return ((Boolean) first).booleanValue() || ((Boolean) second).booleanValue();
    }
  }