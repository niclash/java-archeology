// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryFunction;
import jgl.BinaryPredicate;

/**
 * Binder2ndPredicate is a unary predicate object that allows you to apply a binary 
 * predicate to an operand and a predefined value. The reason that it's called 
 * Binder2ndPredicate is that the predefined value is always used as the 2nd parameter 
 * to the binary predicate.
 * <p>
 * @see jgl.Binder2nd
 * @see jgl.Binder1stPredicate
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Binder2ndPredicate implements UnaryPredicate
  {
  BinaryPredicate myPredicate;
  Object myObject;

  /**
   * Construct myself with a binary predicate object and a predefined value.
   * @param predicate The binary predicate object.
   * @param value The object to use as the 2nd parameter.
   */
  public Binder2ndPredicate( BinaryPredicate predicate, Object value )
    {
    myPredicate = predicate;
    myObject = value;
    }

  /**
   * Perform my binary predicate on the operand using the operand as the 1st parameter
   * and the predefined value as the 2nd parameter.
   * @param object The operand.
   * @return predicate( value, object )
   */
  public boolean execute( Object object )
    {
    return myPredicate.execute( object, myObject );
    }
  }