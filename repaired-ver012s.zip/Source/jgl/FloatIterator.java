// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.FloatArray;
import jgl.RandomAccessIterator;

/**
 * An FloatIterator is a random access iterator that allows you to iterate through
 * an array of floats.
 * <p>
 * @see jgl.RandomAccessIterator
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class FloatIterator implements RandomAccessIterator
  {
  FloatArray myFloatArray;
  float[] myArray;
  int myIndex;
  
  /**
   * Return an iterator positioned at the first element of a particular array.  
   * @param array The array whose first element I will be positioned at.
   */
  public static FloatIterator begin( float[] array ) 
    {
    return new FloatIterator( array, 0, new FloatArray( array ) );
    }

  /**
   * Return an iterator positioned at the first element of a particular array.  
   * @param array The array whose first element I will be positioned at.
   * @param floatArray The container the iterator is associated with.
   */
  public static FloatIterator begin( float[] array, FloatArray floatArray ) 
    {
    return new FloatIterator( array, 0, floatArray );
    }

  /**
   * Return an iterator positioned immediately after the last element of a particular array.
   * @param array The array whose last element I will be positioned after.
   */
  public static FloatIterator end( float[] array )
    {
    return new FloatIterator( array, array.length, new FloatArray( array ) );
    }

  /**
   * Return an iterator positioned immediately after the last element of a particular array.
   * @param array The array whose last element I will be positioned after.
   * @param floatArray The container the iterator is associated with.
   */
  public static FloatIterator end( float[] array, FloatArray floatArray )
    {
    return new FloatIterator( array, array.length, floatArray );
    }

  /**
   * Construct myself to be an iterator with no associated data structure or position.
   */
  public FloatIterator()
    {
    }

  /**
   * Construct myself to be a copy of an existing iterator.
   * @param iterator The iterator to copy.
   */
  public FloatIterator( FloatIterator iterator )
    {
    myFloatArray = iterator.myFloatArray;
    myArray = iterator.myArray;
    myIndex = iterator.myIndex;
    }

  /**
   * Construct myself to be an iterator positioned at the first element of a specified
   * array.
   * @param array The array whose first element I will be positioned at.
   */
  public FloatIterator( float array[] )
    {
    this( array, 0, new FloatArray( array ) );
    }

  /**
   * Construct myself to be an iterator positioned at the first element of a specified
   * array.
   * @param array The array whose first element I will be positioned at.
   * @param floatArray The container the iterator is associated with.
   */
  public FloatIterator( float array[], FloatArray floatArray )
    {
    this( array, 0, floatArray );
    }


  /**
   * Construct myself to be positioned at a particular index of a specific array.
   * @param array My associated array.
   * @param index My associated index.
   */
  public FloatIterator( float[] array, int index )
    {
    this( array, index, new FloatArray( array ) );
    }

  /**
   * Construct myself to be positioned at a particular index of a specific array.
   * @param array My associated array.
   * @param index My associated index.
   * @param floatArray The container the iterator is associated with.
   */
  public FloatIterator( float[] array, int index, FloatArray floatArray )
    {
    myFloatArray = floatArray;
    myArray = array;
    myIndex = index;
    }

  /**
   * Return a clone of myself.
   */
  public Object clone()
    {
    return new FloatIterator( this );
    }

  /**
   * Return my current index.
   */
  public int index()
    {
    return myIndex;
    }

  /**
   * Return true if a specified object is the same kind of iterator as me 
   * and is positioned at the same element.
   * @param object Any object.
   */
  public boolean equals( Object object )
    {
    return object instanceof FloatIterator && equals( (FloatIterator) object );
    }

  /**
   * Return true if iterator is positioned at the same element as me.
   * @param iterator The iterator to compare myself against.
   */
  public boolean equals( FloatIterator iterator )
    {
    return iterator.myIndex == myIndex && iterator.myArray == myArray;
    }

  /**
   * Return true if I'm before a specified iterator.
   * @param iterator The iterator to compare myself against.
   */
  public boolean less( RandomAccessIterator iterator )
    {
    return myIndex < ((FloatIterator) iterator).myIndex;
    }

  /**
   * Return the object that is a specified distance from my current position.
   * @param offset The offset from my current position.
   */
  public Object get( int offset )
    {
    return new Float( myArray[ myIndex + offset ] );
    }

  /**
   * Write an object at a specified distance from my current position.
   * @param offset The offset from my current position.
   * @param object The object to write.
   */
  public void put( int offset, Object object )
    {
    myArray[ myIndex + offset ] = ((Float) object).floatValue();
    }

  /**
   * Return true if I'm positioned at the first item of my input stream.
   */
  public boolean atBegin()
    {
    return myIndex == 0;
    }

  /**
   * Return true if I'm positioned after the last item in my input stream.
   */
  public boolean atEnd()
    {
    return myIndex == myArray.length;
    }

  /**
   * Return true if there are more elements in my input stream.
   */
  public boolean hasMoreElements()
    {
    return myIndex < myArray.length;
    }

  /**
   * Advance by one.
   */
  public void advance()
    {
    myIndex++;
    }

  /**
   * Advance by a specified amount.
   * @param n The amount to advance.
   */
  public void advance( int n )
    {
    myIndex += n;
    }

  /**
   * Retreat by one.
   */
  public void retreat()
    {
    myIndex--;
    }

  /**
   * Retreat by a specified amount.
   * @param n The amount to retreat.
   */
  public void retreat( int n )
    {
    myIndex -= n;
    }

  /**
   * Return the next element in my input stream.
   */
  public Object nextElement()
    {
    return new Float( myArray[ myIndex++ ] );
    }

  /**
   * Return the object at my current position.
   */
  public Object get()
    {
    return new Float( myArray[ myIndex ] );
    }

  /**
   * Set the object at my current position to a specified value.
   * @param object The object to be written at my current position.
   */
  public void put( Object object )
    {
    myArray[ myIndex ] = ((Float) object).floatValue();
    }

  /**
   * Return the distance from myself to another iterator.
   * I should be before the specified iterator.
   * @param iterator The iterator to compare myself against.
   */
  public int distance( ForwardIterator iterator )
    {
    return ((FloatIterator) iterator).myIndex - myIndex;
    }

  /** 
   * Return null for my associated Container since none needs to exist.
   */
  public Container getContainer() 
    {
    return myFloatArray;
    }
  }
