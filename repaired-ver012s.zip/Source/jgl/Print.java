// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.io.PrintStream;
import jgl.UnaryFunction;

/**
 * Print is a unary function object that prints its operand to a PrintStream followed by
 * a newline.
 * <p>
 * @see jgl.OutputStreamIterator
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Print implements UnaryFunction
  {
  PrintStream my_stream;

  /**
   * Construct myself to print all objects to the standard output stream, System.out.
   */
  public Print()
    {
    my_stream = System.out;
    }

  /**
   * Construct myself to print all objects to the specified PrintStream.
   * @param stream The PrintStream.
   */
  public Print( PrintStream stream )
    {
    my_stream = stream;
    }

  /**
   * Print my operand to my PrintStream.
   * @param object The operand.
   * @return The operand.
   */
  public Object execute( Object object )
    {
    my_stream.println( object );
    return object;
    }
  }