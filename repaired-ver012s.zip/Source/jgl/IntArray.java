// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.util.Enumeration;
import jgl.ArrayAdapter;
import jgl.ForwardIterator;
import jgl.Comparing;
import jgl.Printing;
import jgl.InvalidOperationException;
import jgl.IntIterator;

/**
 * IntArray allows a native array of ints to be accessed like a Container.
 * It is particularly useful for applying generic algorithms like Sorting.sort()
 * to a native array.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public class IntArray extends ArrayAdapter
  {
  int myArray[];

  public IntArray( int array[] )
    {
    myArray = array;
    }

  public IntArray( IntArray array )
    {
    myArray = array.myArray;
    }

  /**
   * Return a shallow copy of myself.
   */
  public Object clone()
    {
    return new IntArray( this );
    }

  /**
   * Return a string that describes me.
   */
  public String toString()
    {
    return Printing.toString( this, "int[]" );
    }

  /**
   * Return true if I'm equal to a specified object.
   * @param object The object to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public boolean equals( Object object )
    {
    return Comparing.equal( this, (IntArray) object );
    }
  
  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return myArray.length;
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return myArray.length;
    }

  /**
   * Return an Enumeration of my components.
   */
  public Enumeration elements()
    {
    return IntIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public ForwardIterator start()
    {
    return IntIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public ForwardIterator finish()
    {
    return IntIterator.end( myArray, this );
    }

  /**
   * Return the integer at the specified index as a Integer object.
   * @param index The index.
   */
  public Object at( int index )
    {
    return new Integer( myArray[index] );
    }

  /**
   * Set the object at a specified index.  The object must be a Integer
   * @param index The index.
   * @param object The object to place at the specified index.
   * @exception java.lang.ClassCastException if object is not a Integer
   * @exception java.lang.IndexOutOfBoundsException if object is not a Integer
   */
  public void put( int index, Object object )
    {
    myArray[index] = ((Integer)object).intValue();
    }
  }
