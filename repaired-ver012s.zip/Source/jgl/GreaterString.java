// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BinaryPredicate;

/**
 * GreaterString is a binary predicate that assumes that both of its operands are
 * instances of String and returns true if the first operand is greater than
 * the second operand.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class GreaterString implements BinaryPredicate
  {
  /**
   * Return true if the first operand is greater than the second operand.
   * @param first The first operand, which must be an instance of String.
   * @param second The second operand, which must be an instance of String.
   * @return first > second
   */
  public boolean execute( Object first, Object second )
    {
    return ((String) first).compareTo( (String) second ) > 0;
    }
  }