// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.util.Enumeration;
import jgl.ForwardIterator;

/**
 * Container is the interface that is implemented by all of the
 * Java Generic Library containers. 
 * <p>
 * @see jgl.Array
 * @see jgl.Deque
 * @see jgl.DList
 * @see jgl.HashMap
 * @see jgl.HashSet
 * @see jgl.OrderedMap
 * @see jgl.OrderedSet
 * @see jgl.PriorityQueue
 * @see jgl.Queue
 * @see jgl.SList
 * @see jgl.Stack
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public interface Container extends Cloneable
  {
  /**
   * Return a shallow copy of myself.
   */
  public Object clone();

  /**
   * Return a string that describes me.
   */
  public String toString();

  /**
   * Return true if I'm equal to a specified object.
   * @param object The object to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public boolean equals( Object object );
  
  /**
   * Return the number of objects that I contain.
   */
  public int size();

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize();

  /**
   * Return true if I contain no objects.
   */
  public boolean isEmpty();

  /**
   * Remove all of my objects.
   */
  public void clear();

  /**
   * Return an Enumeration of the components in this container
   */
  public Enumeration elements();

  /**
   * Return an iterator positioned at my first item.
   */
  public ForwardIterator start();

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public ForwardIterator finish();

  /**
   * Add an object to myself. If appropriate, return the object that it replaced, otherwise
   * return null.
   */
  public Object add( Object object );
  }
