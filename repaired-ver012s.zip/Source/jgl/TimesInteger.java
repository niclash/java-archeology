// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BinaryFunction;

/**
 * TimesInteger is a binary function object that assumes that both of its operands are
 * instances of Integer and returns the first operand multiplied by the second operand.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class TimesInteger implements BinaryFunction
  {
  /**
   * Return the result of multiplying the first operand by the second operand.
   * @param first The first operand, which must be an instance of Integer.
   * @param second The second operand, which must be an instance of Integer.
   * @return first * second
   */
  public Object execute( Object first, Object second )
    {
    return new Integer( ((Integer) first).intValue() * ((Integer) second).intValue() );
    }
  }