// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BinaryPredicate;

/**
 * BinaryNegate is a binary predicate that returns true if the result of executing
 * a binary predicate on its operands is false.
 * <p>
 * @see jgl.UnaryNegate
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class BinaryNegate implements BinaryPredicate
  {
  BinaryPredicate myPredicate;

  /**
   * Construct myself with a single binary predicate object.
   * @param predicate The binary predicate object.
   */
  public BinaryNegate( BinaryPredicate predicate )
    {
    myPredicate = predicate;
    }

  /**
   * Perform my binary predicate on the operands and return true if the predicate 
   * returns false.
   * @param first The first operand.
   * @param second The second operand.
   * @return !function( first, second )
   */
  public boolean execute( Object first, Object second )
    {
    return !myPredicate.execute( first, second );
    }
  }