// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

/**
 * BidirectionalIterator is the interface of all iterators that can 
 * read and/or write one item at a time in a forwards or backwards direction. 
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public interface BidirectionalIterator extends ForwardIterator
  {
  /**
   * J++ requires clone 
   */
  public Object clone();

  /**
   * Retreat by one.
   */
  public void retreat();

  /**
   * Retreat by a specified amount.
   * @param n The amount to retreat.
   */
  public void retreat( int n );

  /**
   * Return the object that is a specified distance from my current position.
   * @param offset The offset from my current position.
   */
  public Object get( int offset );

  /**
   * Return the object at my current position.
   */
  public Object get();

  /**
   * Replace the object at a specified distance from my current position.
   * @param offset The offset from my current position.
   * @param object The object to write.
   */
  public void put( int offset, Object object );
  }
