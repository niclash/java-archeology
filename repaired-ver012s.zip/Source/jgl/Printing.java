// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.InputIterator;
import jgl.Container;

/**
 * Printing is a class that contains generic printing algorithms.
 * <p>
 * @see jgl.examples.PrintingExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Printing
  {
  private Printing()
    {
    }

  /**
   * Return a string that describes a container.
   * @param container The container to describe.
   * @param name The type of the container.
   * @return A string that describes the container.
   */
  static String toString( Container container, String name )
    {
    return name + toString( container.start(), container.finish() );
    }

  /**
   * Return a string that describes the contents of the sequence
   * associated with an iterator.
   * @param first An iterator positioned at the first element to describe.
   * @param last An iterator positioned immediately after the last element to describe.
   * @return A string that describes the container's contents.
   */
  public static String toString( InputIterator first, InputIterator last )
    {
    if( first.atEnd() )
      return "()";

    InputIterator firstx = (InputIterator) first.clone();
    StringBuffer buffer = new StringBuffer();
    buffer.append( "( " );

    while( !firstx.equals( last ) )
      {
      buffer.append( firstx.nextElement() );

      if( !firstx.equals( last ) )
        buffer.append( ", " );
      }

    buffer.append( " )");
    return buffer.toString();
    }

  /**
   * Print the contents of the data structure associated with a particular iterator
   * to the standard output stream, System.out.
   * @param first An iterator positioned at the first element to print.
   * @param last An iterator positioned immediately after the last element to print.
   */
  public static void print( InputIterator first, InputIterator last )
    {
    System.out.print( toString( first, last ) );
    }

  /**
   * Print the contents of the data structure associated with a particular iterator
   * to the standard output stream, System.out, followed by a newline.
   * @param first An iterator positioned at the first element to print.
   * @param last An iterator positioned immediately after the last element to print.
   */
  public static void println( InputIterator first, InputIterator last )
    {
    System.out.println( toString( first, last ) );
    }
  }
