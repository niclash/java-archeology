// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.util.Enumeration;
import jgl.Container;
import jgl.Sequence;
import jgl.ForwardIterator;
import jgl.SList;

/**
 * A Queue is an adapter that allows you to use any Sequence as a
 * first-in, first-out data structure. By default, a Queue uses an
 * SList.
 * <p>
 * @see jgl.Sequence
 * @see jgl.SList
 * @see jgl.examples.QueueExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Queue implements Container
  {
  Sequence mySequence;

  /**
   * Construct myself to be an empty Queue.
   * Use an SList for my underlying implementation.
   */
  public Queue()
    {
    mySequence = new SList();
    }

  /**
   * Construct myself with a specified Sequence as my underlying implementation.
   * @param sequence The empty Sequence to be used for my implementation.
   */
  public Queue( Sequence sequence )
    {
    mySequence = sequence;
    }

  /**
   * Construct myself to be a shallow copy of a specified Queue.
   * @param queue The Queue to be copied.
   */
  public Queue( Queue queue )
    {
    mySequence = (Sequence) queue.mySequence.clone();
    }

  /**
   * Become a shallow copy of a Queue.
   * @param queue The Queue to be copied.
   */
  public void copy( Queue queue )
    {
    if( this != queue )
      mySequence = (Sequence) queue.mySequence.clone();
    }

  /**
   * Return a string that describes me.
   */
  public String toString()
    {
    return "Queue( " + mySequence.toString() + " )";
    }

  /**
   * Return true if object is a Queue whose underlying sequence is equal to mine.
   * @param object Any object.
   */
  public boolean equals( Object object )
    {
    return object instanceof Queue && equals( (Queue) object );
    }

  /**
   * Return true if a Queue's sequence is equal to mine.
   * @param queue The Queue to compare myself against.
   */
  public boolean equals( Queue queue )
    {
    return mySequence.equals( queue.mySequence );
    }

  /**
   * Return a shallow copy of myself.
   * A shallow copy is made of my underlying sequence.
   */
  public Object clone()
    {
    return new Queue( (Sequence) mySequence.clone() );
    }

  /**
   * Remove all of my objects.
   */
  public void clear()
    {
    mySequence.clear();
    }

  /**
   * Return true if I contain no objects.
   */
  public boolean isEmpty()
    {
    return mySequence.isEmpty();
    }

  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return mySequence.size();
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return mySequence.maxSize();
    }

  /**
   * Return the object at my front.
   * @exception jgl.InvalidOperationException If the Queue is empty.
   */
  public Object front()
    {
    return mySequence.front();
    }

  /**
   * Return the object at my back.
   * @exception jgl.InvalidOperationException If the Queue is empty.
   */
  public Object back()
    {
    return mySequence.back();
    }

  /**
   * Add an object to my back.
   * @param object The object to add.
   */
  public Object add( Object object )
    {
    return mySequence.add( object );
    }

  /**
   * Add an object to my back.
   */
  public void push( Object object )
    {
    mySequence.add( object );
    }

  /**
   * Remove an object from my front and return it.
   * @exception jgl.InvalidOperationException If the Queue is empty.
   */
  public Object pop()
    {
    return mySequence.popFront();
    }

  /**
   * Return an Enumeration of my components.
   */
  public Enumeration elements()
    {
    return mySequence.elements();
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public ForwardIterator start()
    {
    return mySequence.start();
    }

  /**
   * Return an iterator positioned immediately afer my last item.
   */
  public ForwardIterator finish()
    {
    return mySequence.finish();
    }

  /**
   * Swap my contents with another Queue.
   * @param queue The Queue that I will swap my contents with.
   */
  public void swap( Queue queue )
    {
    Sequence tmpSequence = mySequence;
    mySequence = queue.mySequence;
    queue.mySequence = tmpSequence;
    }
  }
