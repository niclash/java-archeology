// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

final class Allocator
  {
  public static int pageSize() 
    {
    return 1024;
    }

  public static int maxSize()
    {
    return Integer.MAX_VALUE;
    }
  }
