// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryFunction;

/**
 * NegateInteger is a unary function object that assumes that its operand is an instance of
 * Integer and returns its negation.
 * <p>
 * @see jgl.BinaryNegate
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class NegateInteger implements UnaryFunction
  {
  /**
   * Return the negation of my operand.
   * @param object The operand, which must be an instance of Integer.
   * @return -object
   */
  public Object execute( Object object )
    {
    return new Integer( -((Integer) object).intValue() );
    }
  }