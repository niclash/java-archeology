// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.InputIterator;
import jgl.UnaryFunction;
import jgl.Container;

/**
 * The Applying class contains generic applying algorithms.
 * <p>
 * @see jgl.examples.ApplyingExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Applying
  {
  private Applying() 
    {
    }

  /**
   * Apply a unary function to every element in a specified range.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element in the range.
   * @param last An iterator positioned immediately after the last element in the range.
   * @param function The unary function to apply.
   * @return The unary function.
   */
  public static UnaryFunction forEach( InputIterator first, InputIterator last, UnaryFunction function )
    {
    InputIterator firstx = (InputIterator) first.clone();

    while( !firstx.equals( last ) )
      {
      function.execute( firstx.get() );
      firstx.advance();
      }

    return function;
    }

  /**
   * Apply a unary function to every element in a container.
   * The time complexity is linear and the space complexity is constant.
   * @param container The container.
   * @param function The unary function to apply.
   * @return The unary function.
   */
  public static UnaryFunction forEach( Container container, UnaryFunction function )
    {
    return forEach( container.start(), container.finish(), function );
    }
  }
