// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.util.Enumeration;
import jgl.Container;
import jgl.Sequence;
import jgl.ForwardIterator;
import jgl.Array;

/**
 * A Stack is an adapter that allows you to use any Sequence as a
 * first-in, last-out data structure. By default, a Stack uses an
 * Array.
 * <p>
 * @see jgl.Sequence
 * @see jgl.Array
 * @see jgl.examples.StackExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Stack implements Container
  {
  Sequence mySequence;

  /**
   * Construct myself to be an empty Stack.
   * Use an Array for my underlying implementation.
   */
  public Stack()
    {
    mySequence = new Array();
    }

  /**
   * Construct myself with a specified Sequence as my underlying implementation.
   * @param sequence The empty Sequence to be used for my implementation.
   */
  public Stack( Sequence sequence )
    {
    mySequence = sequence;
    }

  /**
   * Construct myself to be a shallow copy of a specified Stack.
   * @param stack The Stack to be copied.
   */
  public Stack( Stack stack )
    {
    mySequence = (Sequence) stack.mySequence.clone();
    }

  /**
   * Become a shallow copy of a specified Stack.
   * A shallow copy is made of the Stack's underlying sequence.
   * @param stack The Stack to be copied.
   */
  public void copy( Stack stack )
    {
    if( this != stack )
      mySequence = (Sequence) stack.mySequence.clone();
    }

  /**
   * Return a shallow copy of myself.
   */
  public Object clone()
    {
    return new Stack( (Sequence) mySequence.clone() );
    }

  /**
   * Return a string that describes me.
   */
  public String toString()
    {
    return "Stack( " + mySequence.toString() + " )";
    }

  /**
   * Return true if object is a Stack whose underlying sequence is equal to mine.
   * @param object Any object.
   */
  public boolean equals( Object object )
    {
    return object instanceof Stack && equals( (Stack) object );
    }

  /**
   * Return true if a specified Stack's sequence is equal to mine.
   * @param stack The Stack to compare myself against.
   */
  public boolean equals( Stack stack )
    {
    return mySequence.equals( stack.mySequence );
    }

  /**
   * Return true if I contain no objects.
   */
  public boolean isEmpty()
    {
    return mySequence.isEmpty();
    }

  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return mySequence.size();
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return mySequence.maxSize();
    }

  /**
   * Return the last object that was pushed onto me.
   * @exception jgl.InvalidOperationException if the Stack is empty.
   */
  public Object top()
    {
    return mySequence.back();
    }

  /** 
   * Push an object.  Return null as add's always work for Stacks
   * @param object The object to push.
   */
  public Object add( Object object )
    {
    mySequence.pushBack( object );
    return null;
    }

  /**
   * Push an object.
   * @param object The object to push.
   */
  public void push( Object object )
    {
    mySequence.pushBack( object );
    }

  /**
   * Pop the last object that was pushed onto me.
   * @exception jgl.InvalidOperationException if the Stack is empty.
   */    
  public Object pop()
    {
    return mySequence.popBack();
    }

  /**
   * Remove all of my objects.
   */
  public void clear()
    {
    mySequence.clear();
    }

  /**
   * Return an Enumeration of my components.
   */
  public Enumeration elements()
    {
    return mySequence.elements();
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public ForwardIterator start()
    {
    return mySequence.start();
    }

  /**
   * Return an iterator positioned immediately afer my last item.
   */
  public ForwardIterator finish()
    {
    return mySequence.finish();
    }

  /**
   * Swap my contents with another Stack.
   * @param stack The Stack that I will swap my contents with.
   */
  public void swap( Stack stack )
    {
    Sequence tmp_sequence = mySequence;
    mySequence = stack.mySequence;
    stack.mySequence = tmp_sequence;
    }
  }
