// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.Container;

/**
 * Set is the interface that is implemented by all of the
 * Java Generic Library sets. 
 * <p>
 * @see jgl.HashSet
 * @see jgl.OrderedSet
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public interface Set extends Container
  {
  /**
   * Return the first object that matches the given object, or null if no match exists.
   * @param object The object to match against.
   * @see Set#put
   */
  public Object get( Object object );

  /**
   * If the object doesn't exist, add the object and return null, otherwise replace the 
   * first object that matches and return the old object. 
   * @param object The object to add.
   * @see Set#get
   */
  public Object put( Object object );

  /**
   * Remove all objects that match the given object.
   * @param object The object to match for removals
   * @return the object removed, or null if the object was not found.
   */
   public Object remove( Object key );
  }
