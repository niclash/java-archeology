// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BinaryFunction;

/**
 * PlusString is a binary function object that assumes that both of its operands are
 * instances of String and returns the concatenation of the operands.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class PlusString implements BinaryFunction
  {
  /**
   * Return the concatenation of the two operands.
   * @param first The first operand, which must be an instance of String.
   * @param second The second operand, which must be an instance of String.
   * @return first + second
   */
  public Object execute( Object first, Object second )
    {
    return ((String) first) + ((String) second);
    }
  }