// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.InputIterator;
import jgl.EqualTo;
import jgl.Container;
import jgl.UnaryPredicate;
import jgl.BinaryPredicate;

/**
 * The Finding class contains generic Finding algorithms.
 * <p>
 * @see jgl.examples.FindingExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Finding
  {
  private Finding()
    {
    }

  /**
   * Find the first element in a sequence that matches a particular object using equals().
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param object The object to find.
   * @return An iterator positioned at the first element that matches. If no match is 
   * found, return an iterator positioned immediately after the last element of 
   * the sequence. 
   */
  public static InputIterator find( InputIterator first, InputIterator last, Object object )
    {
    InputIterator firstx = (InputIterator) first.clone();

    while( !firstx.equals( last ) && !( firstx.get().equals( object ) ) )
      firstx.advance();

    return firstx;
    }

  /**
   * Find the first element in a container that matches a particular object using equals().
   * The time complexity is linear and the space complexity is constant.
   * @param container The container.
   * @param object The object to find.
   * @return An iterator positioned at the first element that matches. If no match is 
   * found, return an iterator positioned immediately after the last element of 
   * the container. 
   */
  public static InputIterator find( Container container, Object object )
    {
    return find( container.start(), container.finish(), object );
    }

  /**
   * Find the first element in a sequence that satisfies a predicate.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param predicate A unary predicate.
   * @return An iterator positioned at the first element that matches. If no match is 
   * found, return an iterator positioned immediately after the last element of 
   * the sequence. 
   */
  public static InputIterator findIf( InputIterator first, InputIterator last, UnaryPredicate predicate )
    {
    InputIterator firstx = (InputIterator) first.clone();

    while( !firstx.equals( last ) && !predicate.execute( firstx.get() ) )
      firstx.advance();

    return firstx;
    }

  /**
   * Find the first element in a container that satisfies a predicate.
   * The time complexity is linear and the space complexity is constant.
   * @param container The container.
   * @param predicate A unary predicate.
   * @return An iterator positioned at the first element that matches. If no match is 
   * found, return an iterator positioned immediately after the last element of 
   * the sequence. 
   */
  public static InputIterator findIf( Container container, UnaryPredicate predicate )
    {
    return findIf( container.start(), container.finish(), predicate );
    }

  /**
   * Find the first consecutive sequence of elements that match using equals().
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @return An iterator positioned at the first element in the consecutive sequence. If
   * no consecutive sequence is found, return an iterator positioned immediately after 
   * the last element of the input sequence.
   */
  public static InputIterator adjacentFind( InputIterator first, InputIterator last )
    {
    return adjacentFind( first, last, new EqualTo() );
    }

  /**
   * Find the first consecutive sequence of elements that match using equals().
   * The time complexity is linear and the space complexity is constant.
   * @param container The container to search.
   * @return An iterator positioned at the first element in the consecutive sequence. If
   * no consecutive sequence is found, return an iterator positioned immediately after 
   * the last element of the container.
   */
  public static InputIterator adjacentFind( Container container )
    {
    return adjacentFind( container.start(), container.finish() );
    }

  /**
   * Find the first consecutive sequence of elements that match using a predicate.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param predicate A binary predicate.
   * @return An iterator positioned at the first element in the consecutive sequence. If
   * no consecutive sequence is found, return an iterator positioned immediately after 
   * the last element of the input sequence.
   */
  public static InputIterator adjacentFind( InputIterator first, InputIterator last, BinaryPredicate predicate )
    {
    if( first.equals( last ) )
      return last;

    InputIterator firstx = (InputIterator) first.clone();
    InputIterator next = (InputIterator) first.clone();
    next.advance();

    while( !next.equals( last ) )
      {
      if( predicate.execute( firstx.get(), next.get() ) )
        return firstx;

      firstx.advance();
      next.advance();
      }

    return next;
    }

  /**
   * Find the first consecutive sequence of elements that match using a predicate.
   * The time complexity is linear and the space complexity is constant.
   * @param container The container to search.
   * @param predicate A binary predicate.
   * @return An iterator positioned at the first element in the consecutive sequence. If
   * no consecutive sequence is found, return an iterator positioned immediately after 
   * the last element of the container.
   */
  public static InputIterator adjacentFind( Container container, BinaryPredicate predicate )
    {
    return adjacentFind( container.start(), container.finish(), predicate );
    }
  }
