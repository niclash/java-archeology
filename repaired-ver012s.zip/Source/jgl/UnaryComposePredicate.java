// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryFunction;
import jgl.UnaryPredicate;

/**
 * UnaryCompose is a unary predicate object that returns the result of executing
 * two operations in a specific sequence.
 * <p>
 * @see jgl.UnaryComposePredicate
 * @see jgl.BinaryCompose
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class UnaryComposePredicate implements UnaryPredicate
  {
  UnaryPredicate myPredicate;
  UnaryFunction myFunction;

  /**
   * Construct myself with a unary predicate object and a unary function object.
   * @param predicate The predicate object.
   * @param function The function object.
   */
  public UnaryComposePredicate( UnaryPredicate predicate, UnaryFunction function )
    {
    myPredicate = predicate;
    myFunction = function;
    }

  /**
   * Perform my second unary function on the operand and then return the result of applying 
   * my first unary function object to this result.
   * @param object The operand.
   * @return predicate( function( object ) )
   */
  public boolean execute( Object object )
    {
    return myPredicate.execute( myFunction.execute( object ) );
    }
  }