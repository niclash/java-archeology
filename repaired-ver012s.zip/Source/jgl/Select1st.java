// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryFunction;
import jgl.Pair;

/**
 * Select1st is a unary function that assumes that its operand is a Pair and returns
 * its first instance variable.
 * <p>
 * @see jgl.Select2nd
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Select1st implements UnaryFunction
  {
  /**
   * Return the first instance variable of my operand.
   * @param object The operand, which must be an instance of Pair.
   * @return object.first
   */
  public Object execute( Object object )
    {
    return ((Pair) object).first;
    }
  }