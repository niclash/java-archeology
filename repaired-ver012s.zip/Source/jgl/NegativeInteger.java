// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryPredicate;

/**
 * NegativeInteger is a unary predicate that returns true if its operand is negative.
 * <p>
 * @see jgl.PositiveInteger
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class NegativeInteger implements UnaryPredicate
  {
  /**
   * Return true if the operand is less than zero.
   * @param object The operand, which must be an Integer.
   * @return object < 0
   */
  public boolean execute( Object object )
    {
    return ((Integer) object).intValue() < 0;
    }
  }