// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.InputIterator;
import jgl.UnaryPredicate;
import jgl.Container;

/**
 * The Counting class contains generic counting algorithms.
 * <p>
 * @see jgl.examples.CountingExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Counting
  {
  private Counting()
    {
    }

  /**
   * Return the number of elements in a range that match a particular object using
   * equals(). The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element in the range.
   * @param last An iterator positioned immediately after the last element in the range.
   * @param object The object to count.
   * @return The number of objects that matched.
   */
  public static int count( InputIterator first, InputIterator last, Object object )
    {
    InputIterator firstx = (InputIterator) first.clone();
    int n = 0;

    while( !firstx.equals( last ) )
      if( firstx.nextElement().equals( object ) )
        ++n;

    return n;
    }

  /**
   * Return the number of elements in a container that match a particular object using
   * equals(). The time complexity is linear and the space complexity is constant.
   * @param container The container.
   * @param object The object to count.
   * @return The number of objects that matched.
   */
  public static int count( Container container, Object object )
    {
    return count( container.start(), container.finish(), object );
    }

  /**
   * Return the number of elements in a range that satisfy a predicate.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element in the range.
   * @param last An iterator positioned immediately after the last element in the range.
   * @param predicate A unary predicate.
   * @return The number of objects that matched.
   */
  public static int countIf( InputIterator first, InputIterator last, UnaryPredicate predicate )
    {
    InputIterator firstx = (InputIterator) first.clone();
    int n = 0;

    while( !firstx.equals( last ) )
      if( predicate.execute( firstx.nextElement() ) )
        ++n;

    return n;
    }

  /**
   * Return the number of elements in a container that satisfy a predicate.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element in the range.
   * @param last An iterator positioned immediately after the last element in the range.
   * @param predicate A unary predicate.
   * @return The number of objects that matched.
   */
  public static int countIf( Container container, UnaryPredicate predicate )
    {
    return countIf( container.start(), container.finish(), predicate );
    }
  }
