// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

/**
 * A Pair is an object that contains two other objects. It is
 * most commonly used for conveniently storing and passing pairs
 * of objects.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Pair
  {
  /**
   * The first object.
   */
  public Object first;

  /**
   * The second object.
   */
  public Object second;

  /**
   * Construct myself to hold a pair of objects.
   * @param x The first object.
   * @param y The second object.
   */
  public Pair( Object x, Object y )
    {
    first = x;
    second = y;
    }

  /**
   * Return a string that describes me.
   */
  public String toString()
    {
    return "Pair( " + first + ", " + second + " )";
    }

  public boolean equals( Object object )
    {
    return object instanceof Pair && equals( (Pair) object );
    }

  public boolean equals( Pair pair )
    {
    return first.equals( pair.first ) && second.equals( pair.second );
    }
  }
