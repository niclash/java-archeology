// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BinaryPredicate;
import jgl.HashComparitor;
import jgl.BidirectionalIterator;
import jgl.Container;

/**
 * The Heap class contains generic heap algorithms.
 * <p>
 * @see jgl.examples.HeapExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public class Heap
  {
  private Heap()
    {
    }
  
  /**
   * Assuming that a sequence is already organized as a heap, insert the element that
   * is immediately after the sequence into the heap. The elements are organized
   * according to their hash code. The time complexity is O(logN), where N is the size of 
   * the heap.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   */
  public static void pushHeap( BidirectionalIterator first, BidirectionalIterator last )
    {
    pushHeap( first, last, new HashComparitor() );
    }

  /**
   * Assuming that a sequence is already organized as a heap, insert the element that
   * is immediately after the sequence into the heap. The elements are organized
   * according to a specified comparitor. The time complexity is O(logN), where N is 
   * the size of the heap.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   */
  public static void pushHeap( BidirectionalIterator first, BidirectionalIterator last, BinaryPredicate comparitor )
    {
    pushHeap( first, first.distance( last ) - 1, 0, last.get( -1 ), comparitor );
    }

  static void pushHeap( BidirectionalIterator first, int holeIndex, int topIndex, Object value, BinaryPredicate comparitor )
    {
    int parent = ( holeIndex - 1 ) / 2;

    while( holeIndex > topIndex && comparitor.execute( first.get( parent ), value ) )
      {
      first.put( holeIndex, first.get( parent ) );
      holeIndex = parent;
      parent = ( holeIndex - 1 ) / 2;
      }

    first.put( holeIndex, value );
    }

  /**
   * Assuming that a sequence is organized as a heap, swap its first and last elements
   * and then reorganize every element except for the last element to be a heap. The 
   * elements are organized according to their hash code. 
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   */
  public static void popHeap( BidirectionalIterator first, BidirectionalIterator last )
    {
    popHeap( first, last, new HashComparitor() );
    }

  /**
   * Assuming that a sequence is organized as a heap, swap its first and last elements
   * and then reorganize every element except for the last element to be a heap. The 
   * elements are organized according to a specified comparitor. 
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   */
  public static void popHeap( BidirectionalIterator first, BidirectionalIterator last, BinaryPredicate comparitor )
    {
    Object old = last.get( -1 );
    last.put( -1, first.get() );
    adjustHeap( first, 0, first.distance( last ) - 1, old, comparitor );
    }

  static void adjustHeap( BidirectionalIterator first, int holeIndex, int len, Object value, BinaryPredicate comparitor )
    {
    int topIndex = holeIndex;
    int secondChild = 2 * holeIndex + 2;

    while( secondChild < len )
      {
      if( comparitor.execute( first.get( secondChild ), first.get( secondChild - 1 ) ) )
        secondChild--;

      first.put( holeIndex, first.get( secondChild ) );
      holeIndex = secondChild;
      secondChild = 2 * ( secondChild + 1 );
      }

    if( secondChild == len )
      {
      first.put( holeIndex, first.get( secondChild - 1 ) );
      holeIndex = secondChild - 1;
      }

    pushHeap( first, holeIndex, topIndex, value, comparitor );
    }

  /**
   * Arrange a sequence into a heap that is ordered according to the object's hash codes.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   */
  public static void makeHeap( BidirectionalIterator first, BidirectionalIterator last )
    {
    makeHeap( first, last, new HashComparitor() );
    }

  /**
   * Arrange a sequence into a heap that is ordered according to a comparitor.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   */
  public static void makeHeap( BidirectionalIterator first, BidirectionalIterator last, BinaryPredicate comparitor )
    {
    int len = first.distance( last );

    if( len < 2)
      return;

    int parent = ( len - 2 ) / 2;

    while( true )
      {
      adjustHeap( first, parent, len, first.get( parent ), comparitor );

      if( parent == 0 )
        return;

      parent--;
      }
    }

  /**
   * Sort a heap according to the object's hash codes.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the heap.
   * @param last An iterator positioned immediately after the last element of the heap.
   */
  public static void sortHeap( BidirectionalIterator first, BidirectionalIterator last )
    {
    sortHeap( first, last, new HashComparitor() );
    }

  /**
   * Sort a heap according to a comparitor.
   * The time complexity is linear and the space complexity is constant.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param comparitor A binary predicate that returns true if its first operand is "less" than its second operand.
   */
  public static void sortHeap( BidirectionalIterator first, BidirectionalIterator last, BinaryPredicate comparitor )
    {
    BidirectionalIterator lastx = (BidirectionalIterator) last.clone();

    while( first.distance( lastx ) > 1 )
      {
      popHeap( first, lastx, comparitor );
      lastx.retreat();
      }
    }
  }
