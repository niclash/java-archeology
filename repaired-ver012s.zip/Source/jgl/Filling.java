// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.ForwardIterator;
import jgl.OutputIterator;
import jgl.Container;

/**
 * The Filling class contains generic filling algorithms.
 * <p>
 * @see jgl.examples.FillingExamples
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class Filling
  {
  private Filling()
    {
    }

  /**
   * Fill a specified range with a particular value.
   * @param first An iterator positioned at the first element of the sequence.
   * @param last An iterator positioned immediately after the last element of the sequence.
   * @param object The object to fill the sequence with.
   */
  public static void fill( ForwardIterator first, ForwardIterator last, Object object )
    {
    ForwardIterator firstx = (ForwardIterator) first.clone();

    while( !firstx.equals( last ) )
      {
      firstx.put( object );
      firstx.advance();
      }
    }

  /**
   * Fill a container with a particular value.
   * @param container The container.
   * @param object The object to fill the container with.
   */
  public static void fill( Container container, Object object )
    {
    fill( container.start(), container.finish(), object );
    }

  /**
   * Assign an object to a number of elements starting at a specified location.
   * @param output An iterator positioned at the first element of the sequence.
   * @param n The number of objects to assign.
   * @param object The object to fill the sequence with.
   */
  public static void fillN( OutputIterator output, int n, Object object )
    {
    OutputIterator outputx = (OutputIterator) output.clone();

    while( n-- > 0 )
      {
      outputx.put( object );
      outputx.advance();
      }  
    }
  }
