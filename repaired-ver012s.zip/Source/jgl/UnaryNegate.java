// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryPredicate;

/**
 * UnaryNegate is a unary predicate that returns true if the result of executing
 * a unary predicate on its operands is false.
 * <p>
 * @see jgl.BinaryNegate
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class UnaryNegate implements UnaryPredicate
  {
  UnaryPredicate myPredicate;

  /**
   * Construct myself with a single unary predicate object.
   * @param predicate The unary predicate object, which should be a predicate.
   */
  public UnaryNegate( UnaryPredicate predicate )
    {
    myPredicate = predicate;
    }

  /**
   * Perform my unary predicate on the operand and return true if the predicate 
   * returns false.
   * @param object The operand.
   * @return !predicate( object )
   */
  public boolean execute( Object object )
    {
    return !myPredicate.execute( object );
    }
  }