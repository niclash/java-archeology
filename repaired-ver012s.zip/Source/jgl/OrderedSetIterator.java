// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.BidirectionalIterator;
import jgl.Tree;

/**
 * A OrderedSetIterator is a bidirectional iterator that allows you to iterate through
 * the contents of a OrderedSet.
 * <p>
 * @see jgl.BidirectionalIterator
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class OrderedSetIterator implements BidirectionalIterator
  {
  OrderedSet myOrderedSet;
  Tree myTree;
  TreeNode myNode;

  /**
   * Construct myself to be an iterator with no associated data structure or position.
   */
  public OrderedSetIterator()
    {
    }

  /**
   * Construct myself to be a copy of an existing iterator.
   * @param iterator The iterator to copy.
   */
  public OrderedSetIterator( OrderedSetIterator iterator )
    {
    myOrderedSet = iterator.myOrderedSet;
    myTree = iterator.myTree;
    myNode = iterator.myNode;
    }

  /**
   * Construct myself to be positioned at a particular node in a specified Tree.
   * @param tree My associated tree.
   * @param node My associated node.
   */
  OrderedSetIterator( Tree tree, TreeNode node, OrderedSet set )
    {
    myOrderedSet = set;
    myTree = tree;
    myNode = node;
    }

  /**
   * Return a clone of myself.
   */
  public Object clone()
    {
    return new OrderedSetIterator( this );
    }

  /**
   * Return true if a specified object is the same kind of iterator as me 
   * and is positioned at the same element.
   * @param object Any object.
   */
  public boolean equals( Object object )
    {
    return object instanceof OrderedSetIterator && equals( (OrderedSetIterator) object );
    }

  /**
   * Return true if iterator is positioned at the same element as me.
   * @param iterator The iterator to compare myself against.
   */
  public boolean equals( OrderedSetIterator iterator )
    {
    return myNode == iterator.myNode;
    }

  /**
   * Return true if I'm positioned at the first item of my input stream.
   */
  public boolean atBegin()
    {
    return myNode == myTree.myHeader.left;
    }

  /**
   * Return true if I'm positioned after the last item in my input stream.
   */
  public boolean atEnd()
    {
    return myNode == myTree.myHeader;
    }

  /**
   * Return true if there are more elements in my input stream.
   */
  public boolean hasMoreElements()
    {
    return myNode != myTree.myHeader;
    }

  /**
   * Advance by one.
   */
  public void advance()
    {
    myNode = Tree.increment( myNode );
    }

  /**
   * Advance by a specified amount.
   * @param n The amount to advance.
   */
  public void advance( int n )
    {
    if( n >= 0 )
      while( n-- > 0 )
        advance();
    else
      while( n++ < 0 )
        retreat();
    }

  /**
   * Retreat by one.
   */
  public void retreat()
    {
    myNode = Tree.decrement( myNode );
    }

  /**
   * Retreat by a specified amount.
   * @param n The amount to retreat.
   */
  public void retreat( int n )
    {
    advance( -n );
    }

  /**
   * Return the next element in my input stream.
   */
  public Object nextElement()
    {
    Object object = myNode.object;
    myNode = Tree.increment( myNode );
    return object;
    }

  /**
   * Return the object at my current position.
   */
  public Object get()
    {
    return myNode.object;
    }

  /**
   * OrderedSet the object at my current position to a specified value.
   * @param object The object to be written at my current position.
   */
  public void put( Object object )
    {
    myNode.object = object;
    }

  /**
   * Return the object that is a specified distance from my current position.
   * @param offset The offset from my current position.
   */
  public Object get( int offset )
    {
    TreeNode oldNode = myNode;
    advance( offset );
    Object object = get();
    myNode = oldNode;
    return object;
    }

  /**
   * Write an object at a specified distance from my current position.
   * @param offset The offset from my current position.
   * @param object The object to write.
   */
  public void put( int offset, Object object )
    {
    TreeNode oldNode = myNode;
    advance( offset );
    put( object );
    myNode = oldNode;
    }

  /**
   * Return the distance from myself to another iterator.
   * I should be before the specified iterator.
   * @param iterator The iterator to compare myself against.
   */
  public int distance( ForwardIterator iterator )
    {
    TreeNode node = ((OrderedSetIterator) iterator).myNode;
    int n = 0;

    while( node != myNode )
      {
      ++n;
      node = Tree.decrement( node );
      }

    return n;
    }

  /** 
   * Return my associated container.
   */
  public Container getContainer() 
    {
    return myOrderedSet;
    }
  }
