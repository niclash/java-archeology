// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

/**
 * BinaryFunction is the interface that must be implemented by all binary function objects.
 * Every BinaryFunction object must define a single method called execute() that takes
 * two objects as its arguments and returns an object. BinaryFunction objects are often
 * built to operate on a specific kind of argument and must therefore cast the input 
 * parameters in order to process them.
 * <p>
 * @see jgl.BinaryPredicate
 * @see jgl.UnaryFunction
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public interface BinaryFunction
  {
  /**
   * Return the result of executing with two Object arguments.
   * @param first The first object operand.
   * @param second The second object operand.
   * @return The result of processing the input parameters.
   */
  Object execute( Object first, Object second );
  }