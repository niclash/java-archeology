// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.util.Random;

/**
 * An easy-to-use random number generator.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public class Randomizer
  {
  static Random random = new Random();

  public static int getInt( int hi )
    {
    return getInt( 1, hi );
    }
  
  public static int getInt( int lo, int hi )
    {
    return ( Math.abs( random.nextInt() ) % ( hi - lo + 1 ) ) + lo;
    }
  }