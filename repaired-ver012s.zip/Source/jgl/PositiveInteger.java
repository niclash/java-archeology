// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import jgl.UnaryPredicate;

/**
 * PositiveInteger is a unary predicate that returns true if its operand is positive.
 * <p>
 * @see jgl.NegativeInteger
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public final class PositiveInteger implements UnaryPredicate
  {
  /**
   * Return true if the operand is greater than zero.
   * @param object The operand, which must be an Integer.
   * @return object > 0
   */
  public boolean execute( Object object )
    {
    return ((Integer) object).intValue() > 0;
    }
  }