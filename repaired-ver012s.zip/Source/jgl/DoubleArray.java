// Copyright(c) 1996 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package jgl;

import java.util.Enumeration;
import jgl.ArrayAdapter;
import jgl.ForwardIterator;
import jgl.Comparing;
import jgl.Printing;
import jgl.InvalidOperationException;
import jgl.DoubleIterator;

/**
 * DoubleArray allows a native array of doubles to be accessed like a Container.
 * It is particularly useful for applying generic algorithms like Sorting.sort()
 * to a native array.
 * <p>
 * @version 1.0
 * @author ObjectSpace, Inc.
 */

public class DoubleArray extends ArrayAdapter
  {
  double myArray[];

  public DoubleArray( double array[] )
    {
    myArray = array;
    }

  public DoubleArray( DoubleArray array )
    {
    myArray = array.myArray;
    }

  /**
   * Return a shallow copy of myself.
   */
  public Object clone()
    {
    return new DoubleArray( this );
    }

  /**
   * Return a string that describes me.
   */
  public String toString()
    {
    return Printing.toString( this, "double[]" );
    }

  /**
   * Return true if I'm equal to a specified object.
   * @param object The object to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public boolean equals( Object object )
    {
    return Comparing.equal( this, (DoubleArray) object );
    }
  
  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return myArray.length;
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return myArray.length;
    }

  /**
   * Return an Enumeration of my components.
   */
  public Enumeration elements()
    {
    return DoubleIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public ForwardIterator start()
    {
    return DoubleIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public ForwardIterator finish()
    {
    return DoubleIterator.end( myArray, this );
    }

  /**
   * Return the integer at the specified index as a Double object.
   * @param index The index.
   */
  public Object at( int index )
    {
    return new Double( myArray[index] );
    }

  /**
   * Set the object at a specified index.  The object must be a Double
   * @param index The index.
   * @param object The object to place at the specified index.
   * @exception java.lang.ClassCastException if object is not a Double
   * @exception java.lang.IndexOutOfBoundsException if object is not a Double
   */
  public void put( int index, Object object )
    {
    myArray[index] = ((Double)object).doubleValue();
    }
  }
