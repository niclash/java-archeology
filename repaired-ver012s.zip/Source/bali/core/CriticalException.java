
package bali.core;

import java.lang.Exception;

/*
 *
 * CriticalException
 *
 */
public class CriticalException extends Exception
{

    public CriticalException( String msg )
    {
        super(msg);
    }

}

