
package bali.core;

import bali.core.Global;
import bali.core.Archive;
import bali.core.Application;
import bali.core.ObjectManager;
import bali.core.Task;
import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

import java.io.IOException;
import java.lang.Boolean;

/*
 *
 * GlobalDouble
 *
 */

public class GlobalDouble extends Global
{
    double m_Value;

    public GlobalDouble(Object parent, String Name)
        throws IOException, CriticalException
    {
        super(parent, Name);
        m_MaxLen = ((new Double(Double.MIN_VALUE)).toString()).length()+3;
    }

    public double get() throws NumberFormatException
    {
        super.get_Overhead();
        return m_Value;
    }

    public void set( double value, long pass  )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == pass || m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }

    }

    public void set( double value )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }

    }

    public String toString()
    {
        StringBuffer str;

        str = new StringBuffer((new Double(m_Value)).toString());
        try
        {
            str.setLength(m_MaxLen);
        } catch( StringIndexOutOfBoundsException e)
        {
            Application.getReporter().exception( "Internal Error!\nGlobalDouble.toString()", e );
        }
        return str.toString();
    }

    public String fromString( String str )
    {
        m_Value = (Double.valueOf( str.trim() )).doubleValue();
        return Global.OK;
    }

}

