
package bali.core;

import java.io.IOException;
/*
 *
 * AppInterface
 *
 */
public interface AppInterface
{
    void coldStart() throws Throwable;
    void warmStart() throws Throwable;
    void coolStart() throws Throwable;
}

