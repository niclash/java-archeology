
package bali.core;

import java.io.File;
import java.io.RandomAccessFile;
import java.io.IOException;
import java.io.FilenameFilter;
import java.io.StreamTokenizer;
import java.io.FileInputStream;

import java.awt.Frame;
import java.awt.TextField;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Label;
import java.awt.Event;
import java.awt.Insets;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.FileDialog;

/*
 *
 * ObjectViewer
 *
 */

public class ObjectViewer extends Frame implements FilenameFilter
{
    private static final int MAX_LINES = 20;
    private boolean m_Verbose = false;

    private String[] objNames;
    private String[] objValues;
    private String[] objFunc;

    private TextField[] nameFields;
    private TextField[] valueFields;

    private MenuBar menuBar;
    private Menu menuFile;
    private Menu menuEdit;
    private Menu menuView;
    private short m_NoOfLines;
    private String m_Name;

    public ObjectViewer()
    {
        m_NoOfLines = 5;
        objNames = new String[MAX_LINES];
        objValues = new String[MAX_LINES];
        objFunc = new String[MAX_LINES];
        clear();
        addMenus();
        setClientArea();
        setTitle("Bali ObjectViewer" );
        pack();
        resize( new Dimension( 350,250 ) );
        show();
    }

    void addMenus()
    {
        menuBar = new MenuBar();
        menuFile = new Menu( "&File" );
        menuFile.add( "&New" );
        menuFile.add( "&Open..." );
        menuFile.add( "&Save" );
        menuFile.add( "Save &As..." );
        menuFile.addSeparator();
        menuFile.add( "Printe&r Setup..." );
        menuFile.add( "&Print..." );
        menuFile.addSeparator();
        menuFile.add( "E&xit" );
        menuEdit = new Menu( "&Edit" );
        menuEdit.add( "Cu&t" );
        menuEdit.add( "&Copy" );
        menuEdit.add( "&Paste" );
        menuEdit.addSeparator();
        menuEdit.add( "Pre&ferences..." );
        menuView = new Menu( "&View" );
        menuView.add( "&Update" );
        menuEdit.addSeparator();
        menuView.add( "&5 Lines" );
        menuView.add( "&10 Lines" );
        menuView.add( "15 &Lines" );
        menuView.add( "&20 Lines" );
        menuBar.add( menuFile );
        menuBar.add( menuEdit );
        menuBar.add( menuView);
        setMenuBar( menuBar );
    }

    void setClientArea()
    {
        Label lbl;
        GridBagLayout gb;
        GridBagConstraints gbc;

        removeAll();
        gb = new GridBagLayout();
        gbc = new GridBagConstraints();
        Insets ins = new Insets(2,2,2,2);

        setLayout(gb);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipadx = 2;
        gbc.ipady = 2;
        gbc.insets = ins;
        gbc.weighty = 0.0;

        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.weightx = 0.0;
        gbc.gridwidth = GridBagConstraints.RELATIVE;
        lbl = new Label( "Object Name" );
        gb.setConstraints( lbl, gbc );
        add( lbl );
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        lbl = new Label( "Value");
        gb.setConstraints( lbl, gbc );
        add( lbl );
        nameFields = new TextField[MAX_LINES];
        valueFields = new TextField[MAX_LINES];

        for( int i=0 ; i< m_NoOfLines ; i++ )
        {
            gbc.weightx = 0.7;
            gbc.gridwidth = GridBagConstraints.RELATIVE;
            nameFields[i] = new TextField(200);
            nameFields[i].setEditable(true);
            gbc.anchor = GridBagConstraints.NORTHWEST;
            gb.setConstraints( nameFields[i], gbc );
            add( nameFields[i] );

            gbc.weightx = 0.3;
            gbc.gridwidth = GridBagConstraints.REMAINDER;
            valueFields[i] = new TextField(100);
            valueFields[i].setEditable(true);
            gbc.anchor = GridBagConstraints.NORTHWEST;
            gb.setConstraints( valueFields[i], gbc );
            add( valueFields[i] );
        }
        fillTextFields();
    }

    public boolean handleEvent(Event e)
    {
        if ( e.id == Event.WINDOW_DESTROY ) // any kind of window destroy event
        {
            hide();         // hide the Frame
            dispose();      // tell windowing system to free resources
            return true;
        }

        // use the default behavior: Frame.handleEvent()
        return super.handleEvent(e);
    }

    public boolean keyDown(Event  evt, int  key)
    {
        if( key == Event.F5 )
        {
            update();
            return true;
        }
        return super.keyDown( evt, key );
    }

    public boolean action(Event e, Object arg)
    {
        if ( e.target instanceof MenuItem )
        {
            if( arg.toString() == "&Update" )
                update();
            else if( arg.toString() == "&Open..." )
                openFile();
            else if( arg.toString() == "&Save" )
                saveFile();
            else if( arg.toString() == "Save &As..." )
                saveAsFile();
            else if( arg.toString() == "&New" )
                newFile();
            else if( arg.toString() == "&5 Lines" )
                lines5();
            else if( arg.toString() == "&10 Lines" )
                lines10();
            else if( arg.toString() == "15 &Lines" )
                lines15();
            else if( arg.toString() == "&20 Lines" )
                lines20();
            else
                Application.getReporter().message( "Menuitem " + arg + " not yet implemented." );
            return true;
        }
        return false;
    }

    synchronized void update()
    {
        // Update all the Object values.
        int i;
        String str;
        Object obj;
        ObjectManager om;

        om = Application.getObjectManager();

        for( i=0 ; i < m_NoOfLines ; i++ )
        {
            objNames[i] = nameFields[i].getText();
            if( objNames[i] == "" || objNames[i] == null )
                str = "";
            else
            {
                obj = om.get( objNames[i] );
                if( obj == null )
                    str = Global.UNKNOWN_OBJECT;
                else if( obj instanceof Global )
                    str = ((Global) obj).getGlobalObject(m_Verbose);
                else if( obj instanceof Application )
                    str = ((Application) obj).getGlobalObject(m_Verbose);
                else if( obj instanceof Task )
                    str = ((Task) obj).getGlobalObject(m_Verbose);
                else
                    str = Global.UNKNOWN_CLASS;
            }
            objValues[i] = str;
            valueFields[i].setText( str );
        }
    }

    private void lines5()
    {
        m_NoOfLines = 5;
        setClientArea();
        update();
    }

    private void lines10()
    {
        m_NoOfLines = 10;
        setClientArea();
        update();
    }

    private void lines15()
    {
        m_NoOfLines = 15;
        setClientArea();
        update();
    }

    private void lines20()
    {
        m_NoOfLines = 20;
        setClientArea();
        update();
    }

    private void openFile()
    {
        FileDialog fd = new FileDialog( this, "Open View File", FileDialog.LOAD );

        fd.setFile( "" );
        fd.setFilenameFilter( this );
        fd.show();
        m_Name = fd.getDirectory() + fd.getFile();
        if( m_Name != null && m_Name != "" )
            load(m_Name);
    }

    private void saveFile()
    {
        if( m_Name == null )
            saveAsFile();
        save( m_Name );
    }

    private void saveAsFile()
    {
        FileDialog fd = new FileDialog( this, "Save View File", FileDialog.SAVE );

        fd.setFile( m_Name );
        fd.setFilenameFilter( this );
        fd.show();
        m_Name = fd.getDirectory() + fd.getFile();
        if( m_Name != null && m_Name != "")
            save(m_Name);
    }

    public boolean accept( File dir, String name )
    {
        return name.toLowerCase().endsWith(".bvf");
    }

    private void save( String fileName )
    {

        File f = new File(fileName );
        if( f.isFile() )
            f.delete();

        RandomAccessFile file = null;
        try
        {
            file = new RandomAccessFile( fileName, "rw" );
            file.writeUTF( "[ObjectViewer]\n\n" );
            for( int i=0 ; i < m_NoOfLines ; i++ )
            {
                file.writeUTF( "[Object]\n" );
                file.writeUTF( "Function=get\n" );
                file.writeUTF( "Name=" + objNames[i] + "\n" );
                file.writeUTF( "Value=" + objNames[i] + "\n\n" );
            }
        } catch( IOException e )
        {
            Application.getReporter().exception( "ObjectViewer.save().Couldn't not write file to disk.", e );
        }
        try
        {
            if( file != null )
                file.close();
        } catch( IOException e )
        {
            Application.getReporter().exception( "ObjectViewer.save().Couldn't not close file.", e );
        }

    }

    private void load( String name )
    {
        FileInputStream file = null;
        StreamTokenizer tokens = null;

        newFile();
        try
        {
            file = new FileInputStream( name );
            tokens = new StreamTokenizer( file );
            readTokens( tokens );
        } catch( IOException e)
        {
            Application.getReporter().error( "Archive.load()\nCan't load ObjectViewer File:" + name );
        }

    }

    void readTokens( StreamTokenizer tokens )
        throws IOException
    {
        tokens.resetSyntax();
        tokens.commentChar( ';' );
        tokens.lowerCaseMode(true);
        tokens.quoteChar( '"' );
        tokens.ordinaryChar( '[' );
        tokens.ordinaryChar( ']' );
        tokens.slashSlashComments( false );
        tokens.eolIsSignificant( false );

        tokens.nextToken();
        if( tokens.sval != "[objectviewer]" )
            throw new IOException( "Archive.load()\n[ObjectViewer] was expected." + tokens.sval + " was read. " );
        boolean eof = false;
        int objNo = -1;
        boolean header = true;
        boolean param = false;
        boolean name = false;
        boolean function = false;
        boolean value = false;
        String str = null;
        while( ! eof )
        {
            tokens.nextToken();
            if( tokens.ttype == StreamTokenizer.TT_NUMBER )
                 str = (new Double( tokens.nval)).toString();
            else
                str = tokens.sval;

            if( header && str == "[object]" )
            {
                objNo = objNo + 1;
                param = true;
                value = false;
            }
            if( param && str == "name" )
            {
                name = true;
                param = false;
                header = false;
            }
            if( param && str == "value" )
            {
                value = true;
                param = false;
                header = false;
            }
            if( param && str == "function" )
            {
                function = true;
                param = false;
                header = false;
            }
            if( name )
            {
                objNames[objNo] = str;
                header = true;
                param = true;
                value = false;
            }
            if( value )
            {
                objValues[objNo] = str;
                header = true;
                param = true;
                value = false;
            }
            if( function )
            {
                objFunc[objNo] = str;
                header = true;
                param = true;
                value = false;
            }
        }
    }

    private void newFile()
    {
        clear();
        fillTextFields();
        update();
    }

    private void clear()
    {
        int i;

        for( i=0 ; i < MAX_LINES ; i++ )
        {
            objNames[i] = "";
            objValues[i] = "";
        }

    }

    private void fillTextFields()
    {
        for( int i=0 ; i < m_NoOfLines ; i++ )
        {
            nameFields[i].setText( objNames[i] );
            valueFields[i].setText( objValues[i] );
        }
    }
}

