
package bali.core;

import bali.core.Global;
import bali.core.Archive;
import bali.core.Application;
import bali.core.ObjectManager;
import bali.core.Task;
import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

import java.io.IOException;
import java.lang.Boolean;

/*
 *
 * GlobalChar
 *
 */

public class GlobalChar extends Global
{
    public char m_Value;

    public GlobalChar(Object parent, String Name)
        throws IOException, CriticalException
    {
        super(parent, Name);
        m_MaxLen = 5;
    }

    public char get() throws NumberFormatException
    {
        super.get_Overhead();
        return m_Value;
    }

    public void set( char value, long pass )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == pass || m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public void set( char value )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public String toString()
    {
        StringBuffer str;

        str = new StringBuffer((new Integer(m_Value)).toString());
        try
        {
            str.setLength(m_MaxLen);
        } catch( StringIndexOutOfBoundsException e)
        {
            Application.getReporter().exception( "Internal Error!\nGlobalChar.toString()", e );
        }
        return str.toString();
    }

    public String fromString( String str )
    {
        int tmp;

        tmp = (Integer.valueOf( str )).intValue();
        tmp = tmp > 65535 ? 65535 : tmp;
        tmp = tmp < 0 ? 0 : tmp;
        m_Value = (char) tmp;
        return Global.OK;
    }

}

