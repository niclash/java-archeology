
package bali.core;

import bali.core.Archive;

import java.io.IOException;
import java.util.NoSuchElementException;

/*
 *
 * TaskInterface
 *
 */

public interface TaskInterface
{
    public final short OK = 0;
    public final short INTERNAL_ERROR = 1;
    public final short INVALID_SYNTAX = 2;

    boolean onTimer() throws Throwable;
    void coldStart() throws Throwable;
    void warmStart() throws Throwable;
    void coolStart() throws Throwable;
}

