
package bali.core;

import java.lang.Exception;

/*
 *
 * ObjectReadOnlyException
 *
 */
public class ObjectReadOnlyException extends Exception
{

    public ObjectReadOnlyException( String msg )
    {
        super(msg);
    }

}

