
package bali.core;

import bali.core.Global;
import bali.core.Archive;
import bali.core.Application;
import bali.core.ObjectManager;
import bali.core.Task;
import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

import java.io.IOException;
import java.lang.Boolean;

/*
 *
 * GlobalByte
 *
 */

public class GlobalByte extends Global
{
    byte m_Value;

    public GlobalByte(Object parent, String Name)
        throws IOException, CriticalException
    {
        super(parent, Name);
    }

    public byte get() throws NumberFormatException
    {
        super.get_Overhead();
        return m_Value;
    }

    public void set( byte value, long pass )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == pass || m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public void set( byte value )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public String toString()
    {
        return (new Integer(m_Value)).toString();
    }

    public String fromString( String str )
    {
        int tmp;

        tmp = (Integer.valueOf( str )).intValue();
        tmp = tmp > 255 ? 255 : tmp;
        tmp = tmp < 0 ? 0 : tmp;
        m_Value = (byte) tmp;
        return Global.OK;
    }

}

