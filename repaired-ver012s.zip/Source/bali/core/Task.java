package bali.core;
import java.lang.Thread;
import java.lang.Throwable;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Hashtable;
import java.io.IOException;
import java.util.NoSuchElementException;

import bali.core.TaskInterface;
import bali.core.GlobalAccessible;
import bali.core.Global;
import bali.core.GlobalLong;
import bali.core.GlobalBool;
import bali.core.GlobalShort;
import bali.core.GlobalString;
import bali.core.Archive;
import bali.core.ObjectManager;
import bali.core.Application;
import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

/*
 *
 * Task
 *
 */

public abstract class Task extends Thread implements TaskInterface, GlobalAccessible
{
    // PRIORITES of Tasks

    public static final int NORMAL = (MAX_PRIORITY - MIN_PRIORITY)/2;
    public static final int BACKGROUND = MIN_PRIORITY;
    public static final int LOW = NORMAL - 1;
    public static final int HIGH = NORMAL + 1;
    public static final int REALTIME = MAX_PRIORITY;

    public GlobalLong   m_Overrun;
    public GlobalLong   m_Cycle;
    public GlobalShort  m_Error;
    public GlobalLong   m_LastAccessTime;

    public GlobalBool   m_Busy;
    public GlobalBool   m_Persistent;
    public GlobalLong   m_sleepInterval;
    public GlobalLong   m_TaskTime;

    protected long      m_FilePointer;
    private long        m_Loop;
    private long        m_FirstTime;
    private Application m_parent;
    private String      m_Name;
	        ObjectManager om;
            Report      reporter;

    public Task( Application parent, String taskname )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        // Constructor of the object
        setName( "BaliTask:" + taskname );  // Setting the Thread object name, debugging purposes

        m_parent = parent;
        m_Name = taskname;

        om = Application.getApp().getObjectManager();
        om.add( parent, this, taskname );

        reporter = Application.getApp().getReporter();

        m_Overrun = new GlobalLong( this, "System.Overrun" );
        m_Overrun.set(0);

        m_Cycle = new GlobalLong( this, "System.Cycle" );
        m_Cycle.set(1000);

        m_Error = new GlobalShort( this, "System.Error" );
        m_Error.set(OK);

        m_LastAccessTime = new GlobalLong( this, "System.LastAccess" );
        m_LastAccessTime.set(0);

        m_TaskTime = new GlobalLong( this, "System.ExecutionTime" );
        m_TaskTime.set(0);

        m_sleepInterval = new GlobalLong( this, "System.SleepTime" );
        m_sleepInterval.set(1000);

        m_FirstTime = 0;

        m_Persistent = new GlobalBool( this, "System.Persistent" );
        m_Persistent.setPassWrite(3246234324L);
        m_Persistent.set(true, 3246234324L);

        m_Busy = new GlobalBool( this, "System.Busy" );
        m_Busy.setPassWrite(9645954834L);
        m_Busy.set(false, 9645954834L);

        m_Loop = 0;

    }

    protected void finalize()
        throws Throwable
    {
        // Destroys the object.
        om.delete(this);
        m_parent.delTaskList( m_Name );
    	super.finalize();
    }

    public void run()
    {
        boolean loop;

        try
        {
            if( Application.isColdStart() )
                coldStart();
            if( Application.isWarmStart() )
                warmStart();
        }
        catch( Throwable e )
        {
            reporter.exception( "", e );
            getThreadGroup().stop();
            return;
        }

        loop = true;
        m_FirstTime = System.currentTimeMillis();

        try
        {
            m_Overrun.set(0);
        }
        catch( Throwable e )
        {
            reporter.exception("Overrun.set(0)", e );
        }

        while( loop )
        {
            try
            {
                loop = oneShot();
                sleep( m_sleepInterval.get() );
            }
            catch( Throwable e )
            {
                Application.getReporter().exception( "Exception caught in Task.oneShot().\nTask " + m_Name + " is terminated.", e );
                break;
            }
        }
    }

    private boolean oneShot() throws Throwable
    {
        boolean retVal;
        long now, starting, ending;

        m_Busy.set(true, 9645954834L);
        starting = System.currentTimeMillis();
        setAccess();                        // Mark time when task was last started
        retVal = onTimer();                 // Execute task one time;
        ending = System.currentTimeMillis();
        m_TaskTime.set(ending - starting);    // Set how long task took to execute.
        m_Overrun.set(m_Overrun.get() + m_TaskTime.get()/m_Cycle.get()); // increment the Overrun indicator.

        // Compute how long to sleep before next execution.
        m_Loop = (ending - m_FirstTime) / m_Cycle.get();
        m_sleepInterval.set( m_FirstTime + ( m_Loop + 1) * m_Cycle.get() - ending);
        m_Busy.set(false, 9645954834L);
        return retVal;
    }

    public boolean isBusy()
    {
        return m_Busy.get();
    }

    public boolean isPersistent()
    {
        return m_Persistent.get();
    }

    public abstract void coldStart() throws Throwable;
    public abstract void warmStart() throws Throwable;
    public abstract void coolStart() throws Throwable;

    public String getGlobalName()
    {
        String str;

        str = "";
        if( m_parent != null )
            str = m_parent.getGlobalName() + ".";
        return str + m_Name;
    }

    public String getGlobalObject( boolean verbose )
    {
        String str="";

        if( verbose )
        {
            str = str + ", " + m_Overrun.toString();
            str = str + ", " + m_Cycle.toString();
            str = str + ", " + m_Error.toString();
            str = str + ", " + m_LastAccessTime.toString();
            str = str + ", " + m_Busy.toString();
            str = str + ", " + m_Persistent.toString();
        }
        else
            str = "";
        return str;
    }

    public Application getParent()
    {
        return m_parent;
    }

    void setFilePointer( long fp )
    {
        m_FilePointer = fp;
    }

    long getFilePointer()
    {
        return m_FilePointer;
    }

    void setAccess()
        throws IOException, ObjectReadOnlyException
    {
        m_LastAccessTime.set(System.currentTimeMillis());
    }

    public void setCycle( long cycle )
        throws IOException, ObjectReadOnlyException
    {
        m_Cycle.set( cycle );
    }

    public long getCycle()
    {
        return m_Cycle.get();
    }

    public void save( Archive ar )
    {
    }

    public void restore( Archive ar )
    {
    }

    public void changeNotification( Object obj )
        throws Throwable
    {
    }
}

