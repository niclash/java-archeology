
package bali.core;

import bali.core.Global;

import java.lang.Runnable;
import java.lang.InterruptedException;
import java.applet.Applet;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/*
 *
 * SocketServer
 *
 * Serves all requests for IO and other Bali specific
 * information.
 *
 */

public class SocketServer extends Global implements Runnable
{
    Thread t = null;		// Server thread

    public SocketServer( Object parent, String name )
        throws IOException, CriticalException
    {
        super(parent, name );
    }

    public void listen( )
    {
        return;				// Nothing specific needed
    }

    public void destroy( )
    {
        Application.getReporter().debug( "Listen::destroy called\n" );
    }

    // Start thread running (allocing if needed
    public synchronized void start( )
    {
        if( t == null )
        {
			t = new Thread( this );
			Application.getReporter().message( "Starting SocketServer...\n" );
			t.setPriority( Thread.MAX_PRIORITY / 4 );
			t.start();
        }
    }

    // Stop thread from running if it exists
    public synchronized void stop( )
    {
        Application.getReporter().message( "SocketServer stopped!!\n" );

        if( t != null )
        {
            t.stop( );
            t = null;
        }
    }

    // Allow join with our thread
    public final void join( )
        throws java.lang.InterruptedException
    {
        try
        {
            if( t != null )
            {
                t.join();
            }
        } catch ( InterruptedException e )
        {
            throw e;
        }

        return;
    }

    // Run method to be started by Thread
    public void run( )
    {
        ServerSocket s = null;	// Socket we're listening to.
        InputStream in = null;	// Socket input stream
        PrintStream out = null;	// Socket output stream
        Socket con = null;		// Current connection

        // Open a new server socket
        try
        {
            s = new ServerSocket( Application.getApp().getSocket() );
        }
        catch ( Exception e )
        {
            Application.getReporter().exception( "Exception while creating a ServerSocket.", e );
        }

        // Print out our socket
        Application.getReporter().debug( "ServerSocket:" + s + "\n" );

        // While the thread is running . . .
        while( t != null )
        {
            // Accept an incomming connection
            try
            {
                con = s.accept( );
				Application.getReporter().debug( "Socket accept: " + con + "\n" );
            }
            catch ( Exception e )
            {
                Application.getReporter().exception( "Socket Accept Exception: ", e );
            }

            // Get the I/O streams from socket
            try
            {
				out = new PrintStream( con.getOutputStream() );
                in = con.getInputStream();
            }
            catch ( Exception e )
            {
                Application.getReporter().message( "Exception while building Socket streams: " + e + "\n" );
            }

            // Print welcome on socket
            out.println( "Connect:" + Application.getApp().getGlobalName() + "\n" );

            // Read what comes in on the socket
            try
            {
                int nbytes;
                boolean done = false;
                byte b[] = new byte[ 1024 ];

                while(!done && ((nbytes = in.read( b, 0, 1024 )) != -1 ))
                {

                    String str = new String( b, 0, 0, nbytes );
                    String cmd;

                    str = str.trim();
                    if( str.startsWith( "get ", 0 ) )
                    {
                        // get command
                        str = (str.substring( 3 )).trim();
                        str = get( str );
                    }
                    else if( str.startsWith( "set ", 0 ) )
                    {
                        // set command
                        str = (str.substring( 3 )).trim();
                        str = set( str );
                    }
                    else if( str.startsWith( "terminate", 0 ) )
                    {
                        str = "\u0003";
                    }
                    else
                        str = "Error {01 = Unknown Command.}";

                    if( str == "\u0003" )
                    {
                        // Abort Connection
                        done = true;
                    }
                    else
                        out.println( str );
                }
                out.flush();
            }
            catch( Exception e )
            {
                Application.getReporter().exception( "Exception while reading Socket.",  e );
            }

            // Close socket
            try
            {
                out.close();
            }
            catch ( Exception e )
            {
                Application.getReporter().exception( "Exception while closing Socket.", e );
            }
        }
    }

    String get( String expr )
    {
        Object obj;

        obj = Application.getObjectManager().get( expr );
        if( obj == null )
            return Global.UNKNOWN_OBJECT;

        if( obj instanceof Global )
            return ((Global) obj).getGlobalName() + " = {" + ((Global) obj).getGlobalObject(false) + " }";
        else if( obj instanceof Task )
            return ((Task) obj).getGlobalName() + " = {" + ((Task) obj).getGlobalObject(false) + " }";
        else if( obj instanceof Application )
            return ((Application) obj).getGlobalName() + " = {" + ((Application) obj).getGlobalObject(false) + " }";
        return Global.ILLEGAL_CLASS + obj.getClass().getName();
    }

    String set( String expr )
    {
        return Global.NOT_YET;
    }

	public void changeNotification( Global obj )
    {
    }

    public String fromString( String str )
    {
        return Global.NOT_APPLICABLE;
    }

    public String toString()
    {
        return "";
    }
}
