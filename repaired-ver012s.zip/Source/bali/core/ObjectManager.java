
package bali.core;

import java.lang.Object;
import java.util.Hashtable;
import java.util.Enumeration;
import java.io.IOException;
import java.lang.NullPointerException;
import java.lang.IllegalArgumentException;
import java.lang.ClassNotFoundException;

import jgl.HashMap;
import jgl.HashMapIterator;

import bali.core.Global;
import bali.core.GlobalBool;
import bali.core.SocketServer;
import bali.core.Task;
import bali.core.CriticalException;

/*
 *
 * ObjectManager
 *
 */

public final class ObjectManager extends Global
{
    static final boolean DUPLICATES = true;
    static final boolean NO_DUPLICATES = false;
    public static final short TYPE_BOOL   = 1;
    public static final short TYPE_BYTE   = 2;
    public static final short TYPE_CHAR   = 3;
    public static final short TYPE_DOUBLE = 4;
    public static final short TYPE_FLOAT  = 5;
    public static final short TYPE_INT    = 6;
    public static final short TYPE_LONG   = 7;
    public static final short TYPE_SHORT  = 8;
    public static final short TYPE_STRING = 9;

    private HashMap objectTable;
    private HashMap notifyTable;
    private HashMap nameTable;

    public ObjectManager()
        throws IllegalArgumentException, NullPointerException, CriticalException, IOException
    {
        objectTable = new HashMap( DUPLICATES );
        notifyTable = new HashMap( DUPLICATES );
        nameTable = new HashMap( NO_DUPLICATES );
        stdInit( null, "System.ObjectManager" );
    }

    public synchronized void add( Object parent, Object obj, String name )
        throws IllegalArgumentException, NullPointerException, CriticalException
    {
        String str;

		if( parent == null )
            parent = this;			// If no Parent, set ObjectManager to be parent...

        if( name != null && obj != null )
        {
            str = "";
            if( parent == this )
                str = name;
            else
                str = convertGlobalName( parent ) + "." + name;
            if( nameTable.get( str ) == null )
            {
                nameTable.add( str, obj );
                objectTable.add( parent, obj );
            }
            else
			{
                IllegalArgumentException e = new IllegalArgumentException("ObjectManager.add(): Same Object already exists.");
                throw e;
			}
        }
        else
		{
            NullPointerException e = new NullPointerException("ObjectManager.add(): Null objects not allowed and Objects must have names.");
            throw e;
		}
    }

    public synchronized void delete( Object obj )
    {
        Object oldObj;
		Object parent;
        String str;

        str = convertGlobalName( obj );
		oldObj = nameTable.remove( str );
        if( oldObj == null && Application.isDebug() )
        {
            Application.getReporter().debug( getClass().getName() + ".delete() is no longer in NameTable.\n" );
        }

		parent = getObjectParent( obj );
		if( parent != null )
            parent = this;

        oldObj = objectTable.remove( parent );
        if( obj instanceof Task )
		{
            Application.getApp().delTaskList( str );
		}

        if( oldObj == null && Application.isDebug() )
        {
            Application.getApp().getReporter().debug( getClass().getName() + ".delete() is no longer in ObjectTable.\n" );
        }
    }

    public String convertGlobalName( Object obj )
    {
        String str = "";


        if( obj instanceof Global )
            str = ((Global) obj).getGlobalName();
        else if( obj instanceof Application )
            str = ((Application) obj).getGlobalName();
        else if( obj instanceof Task )
            str = ((Task) obj).getGlobalName();
        else
            str = Global.UNKNOWN_CLASS;

        return str;
    }

    public Object getObjectParent( Object obj )
    {
        Object parent = null;

        if( obj instanceof Global )
            parent = ((Global) obj).getParent();
        else if( parent instanceof Application )
            parent = ((Application) obj).getParent();
        else if( parent instanceof Task )
            parent = ((Task) obj).getParent();
        return (Object) parent;

    }

    public Enumeration getAll()
    {
        return objectTable.elements();
    }

    public Object get( String name )
    {
        Object obj;

        obj = nameTable.get( name );
        return obj;
    }

    public String set( String expression )
    {
        // Receives a request from the SocketServer.
        // Interprets the result and returns the proper
        // answer.

        return "\u0003";
    }


    public void finalize() throws Throwable
    {
        // Verify that all Objects has been removed from
        // hashtable.
        if( ! nameTable.isEmpty() )
        {
            Application.getApp().getReporter().critical( "Global objects has not been released properly." );
            Application.getApp().getReporter().critical( nameTable.toString() );
        }

        if( ! objectTable.isEmpty() )
        {
            Application.getReporter().critical( "Global objects has not been released properly." );
            String str = objectTable.toString();
            Application.getReporter().critical( str );
        }
    }

    public Archive getArchive()
    {
        return Application.getApp().getArchive();
    }

    public void notifyChange( Object obj )
    {
        // Search the Notify Database, and send the new values
        // to those subscribers.
        //
        // Version 2 to include remote notifications as well.

        Object subscriber;
        String str;

        HashMapIterator hmi = notifyTable.find( obj );

        while( hmi.hasMoreElements() )
        {
            subscriber = hmi.nextElement();
            try
            {
                if( subscriber instanceof Global )
                    ((Global) subscriber).changeNotification( obj );
                if( subscriber instanceof Task )
                    ((Task) subscriber).changeNotification( obj );
                if( subscriber instanceof Application )
                    ( (Application) subscriber).changeNotification( obj );
            }
            catch(Throwable e)
            {
                str = convertGlobalName( subscriber );
                Application.getReporter().exception( "Exception thrown in " + str + ".changeNotification().", e );
            }
        }
    }

    public boolean subscribe( Object subscriber, Object obj )
    {
        if( subscriber != null )
            notifyTable.add( subscriber, obj );
        else
            return false;
        return true;
    }

	public String getGlobalObject(boolean verbose)
    {
        String str;

        str = "";
        if( verbose )
        {
            str = str + ", ObjectTable = { " + objectTable.toString() + "}";
            str = str + ", NameTable = { " + nameTable.toString() + "}";
            str = str + ", NotifyTable = { " + notifyTable.toString() + "}";
        }
        return str;
    }

	public void changeNotification( Global obj )
    {
    }

    public String fromString( String str )
    {
        return Global.NOT_APPLICABLE;
    }

    public String toString()
    {
        return "";
    }
}
