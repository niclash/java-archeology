
package bali.core;

import bali.core.Global;
import bali.core.Archive;
import bali.core.CriticalException;

import java.io.IOException;
/*
 *
 * Report
 *
 */

public class Report extends Global
{
    private boolean m_Interactive;

    public Report( Global parent, String name )
        throws IOException, CriticalException
    {
        super(parent, name);
        m_Interactive = false;
    }

    public void setInteractive( boolean interactive )
    {
        m_Interactive = interactive;
    }

    public boolean getInteractive()
    {
        return m_Interactive;
    }

    public void message( String message )
    {
        if( m_Interactive )
        {
        }
        else
            System.out.println( message );
    }

    public void critical( String message )
		throws CriticalException
    {

        System.out.println( message );
		throw new CriticalException( message );

    }

    public void error( String message )
    {
        if( m_Interactive )
        {
        }
        else
            System.out.println( message );
    }

    public void exception( String mess, Throwable e )
    {
        if( m_Interactive )
        {
        }
        else
        {
            System.out.println( mess + "\n" + e.getMessage() + "\n" );
            e.printStackTrace();
        }
    }

    public void debug( String message )
    {
        if( Application.isDebug() )
        {
            if( m_Interactive )
            {
            }
            else
                System.out.println( message );
        }
    }

    public String getExternalValue()
    {
        return "";
    }

    public void changeNotification( Global obj )
    {
    }

    public String fromString( String str )
    {
        return Global.NOT_APPLICABLE;
    }

    public String toString()
    {
        return "";
    }
}

