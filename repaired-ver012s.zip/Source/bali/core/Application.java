
package bali.core;

import bali.core.Global;
import bali.core.Archive;
import bali.core.Report;
import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;
import bali.core.AppInterface;

import java.lang.InterruptedException;
import java.util.Hashtable;
import java.util.Enumeration;
import java.io.IOException;
import java.awt.TextField;
import java.awt.TextArea;
import java.awt.Font;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Label;
import java.awt.List;
import java.awt.Event;
import java.awt.Insets;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Frame;

/*
 *
 * Application
 *
 *
 * Application declares one instance of the ObjectManager.
 */

public abstract class Application extends Frame implements AppInterface, GlobalAccessible
{
    public static final String PRODUCT = "Bali Core Technology.";
    public static final String VERSION = "Ver 0.11";
    public static final String COPYRIGHT = "Written by: Niclas Hedhman\nCopyright 1997 Bali Automation Ltd, Mauritius\n";

    private static MenuBar menuBar;
    private static Menu menuFile;
    private static Menu menuEdit;
    private static Menu menuView;
    private static TextField tf_Name;
    private static TextField tf_Archive;
    private static TextField tf_Socket;
    private static TextField tf_Objects;
    private static TextField tf_CmdLine;
    private static TextArea ta_Output;
    private static List lst_Threads;

    private static ObjectManager objManager;
    private static Archive m_PersistentStorage;
    private static Report m_ReportManager;
	private static SocketServer m_SocketServer;
    private static int m_SocketNumber = 88;
    private static Application theApp = null;
    private static Hashtable m_Options;
    private static Hashtable m_Parameters;
	private static String m_Name;
    private static String m_CmdLine;

    protected long    m_FilePointer;

    public Application(Object parent, String name)
		throws CriticalException, IOException
    {
        super(name);

		m_Name = name;
        boolean error = false;

        if( theApp == null )
            theApp = this;
        else
            error = true;

        objManager = new ObjectManager();

        objManager.add( parent, this, name );
        m_Options = new Hashtable();
        m_Parameters = new Hashtable();

        if( error )
        {
            String str = new String( "Only one Application object may be created!!!" );

            m_ReportManager.critical( str );
        }

    }

    public boolean isPersistent()
    {
        return true;
    }

    public static Application getApp()
    {
        return theApp;
    }

    public static String[] getAppOptions()
    {
        return null;
    }

    public static TextArea getOutputWindow()
    {
        return ta_Output;
    }

    public static ObjectManager getObjectManager()
    {
        return objManager;
    }

    public static Report getReporter()
    {
        return m_ReportManager;
    }

    public static int getSocket()
    {
        return m_SocketNumber;
    }

    public String getGlobalName()
    {
        return m_Name;
    }

    public String getGlobalObject( boolean verbose )
    {
        String str = "";

        if( verbose )
        {
            str = str + "Parameters = " + m_Parameters.toString();
            str = str + ", Options = " + m_Options.toString();
            str = str + ", " + objManager.toString();
            str = str + ", " + m_PersistentStorage.toString();
            str = str + ", " + m_ReportManager.toString();
            str = str + ", " + m_SocketServer.toString();
	    }
        else
            str = "";
        return str;
    }

    public static Archive getArchive()
    {
        return m_PersistentStorage;
    }

    void setFilePointer( long fp )
    {
        m_FilePointer = fp;
    }

    long getFilePointer()
    {
        return m_FilePointer;
    }

    private static void extractCmdLine( String args[] )
    {
        int i, j;
        char ch;
        String param, value;

        for( i=0 ; i < args.length ; i++ )
        {
            ch = args[i].charAt(0);
            if(  ch == '-' )
            {
                j = find( args[i].substring(1), "=" );
                if( j != -1 )
                {
                    value = args[i].substring(j+1);
                    param = args[i].substring( 1, j-1);
                }
                else
                {
                    value = "";
                    param = args[i].substring(1);
                }
                value.trim();
                param.trim();
                m_Options.put(param.toUpperCase(), value.toUpperCase() );
            }
            else
                m_Parameters.put( args[i].toUpperCase(), new Integer(i) );
        }
    }

    private static int find( String str, String what )
    {
        String s1;
        String s2;
        int j = str.length() - what.length() + 1;

        for( int i = 0 ; i < j ; i++ )
        {
            s1 = str.substring(i, i+what.length() );
            if( s1 == what )
                return i;
        }
        return -1;
    }

    public static boolean isColdStart()
    {
        return m_Options.containsKey( "COLD" );
    }

    public static boolean isWarmStart()
    {
        return m_Options.containsKey( "WARM" );
    }

    public static boolean isDebug()
    {
        return m_Options.containsKey( "DEBUG" );
    }

	public static String getOption( String option )
	{
		return (String) m_Options.get( option );
	}


    public void changeNotification( Object obj )
    {
        // Called by the framework when a subscribed
        // value has changed
        // Default: Do nothing.

    }

    protected void initPersistent()
        throws CriticalException, IOException, ObjectReadOnlyException
    {
		String fileName;

		fileName = getOption( "ps" );
		if( fileName == null )
			fileName = m_Name + ".store";

		m_PersistentStorage = new Archive(null, "System.Archive" );
		if( isColdStart() )
		{
			m_PersistentStorage.openNewArchive( fileName );
			m_PersistentStorage.saveAllCreatedObjects();
		}
		else
		{
			m_PersistentStorage.openExistingArchive( fileName );
			m_PersistentStorage.restoreAllCreatedObjects();
		}

    }

    public boolean handleEvent(Event e)
    {
        if ( e.id == Event.WINDOW_DESTROY ) // any kind of window destroy event
        {
            hide();         // hide the Frame
            dispose();      // tell windowing system to free resources
            System.exit(0); // exit
            return true;
        }

        // use the default behavior: Frame.handleEvent()
        return super.handleEvent(e);
    }

    public boolean keyDown(Event  evt, int  key)
    {
        if( key == Event.F5 )
        {
            onViewUpdate();
            return true;
        }
        return super.keyDown( evt, key );
    }

    public boolean action(Event e, Object arg)
    {
        ObjectViewer ov;

        if ( e.target instanceof MenuItem )
        {
            if( arg == "&Object Viewer..." )
                ov = new ObjectViewer();
            else if( arg == "&Update" )
                onViewUpdate();
            else
                m_ReportManager.message( Global.NOT_YET + "[" + arg + "]" );
            return true;
        }
        return false;
    }


    public void create( String args[] ) throws Throwable
    {
        // Called by main in the starting class.
        m_ReportManager = new Report( null, "System.Reporter" );

        extractCmdLine(args);
        m_CmdLine = "";
        for( int i=0 ; i < args.length ; i++ )
            m_CmdLine = m_CmdLine + args[i] + " ";

        initPersistent();

        System.out.println( PRODUCT + " " + VERSION );
        System.out.println( COPYRIGHT );

        if( isColdStart() )
            coldStart();
        if( isWarmStart() )
            warmStart();
        else
            coolStart();

		m_PersistentStorage.start();
 		m_SocketServer = new SocketServer( null, "System.Communications" );
		m_SocketServer.start();
        onViewCreate();
    }

    public void addTaskList( String name )
    {
        lst_Threads.addItem( name );
    }

    public void delTaskList( String name )
    {
        for( int i=0 ; i < lst_Threads.countItems() ; i++ )
            if( name == lst_Threads.getItem(i) )
            {
                lst_Threads.delItem(i);
                break;
            }
    }

    void addStandardMenu()
    {
        menuBar = new MenuBar();
        menuFile = new Menu( "&Application" );
        menuFile.add( "Start" );
        menuFile.add( "Pause" );
        menuFile.addSeparator();
        menuFile.add( "&Printer Setup..." );
        menuFile.add( "&Print..." );
        menuFile.addSeparator();
        menuFile.add( "E&xit" );
        menuEdit = new Menu( "&Edit" );
        menuEdit.add( "Copy" );
        menuEdit.addSeparator();
        menuEdit.add( "Preferences..." );
        menuView = new Menu( "&View" );
        menuView.add( "&Update" );
        menuView.addSeparator();
        menuView.add( "&Object Viewer..." );
        menuBar.add( menuFile );
        menuBar.add( menuEdit );
        menuBar.add( menuView);
        setMenuBar( menuBar );
    }

    void addStandardComponents()
    {
        TextField tf;
        Label lbl;
        GridBagLayout gb;
        GridBagConstraints gbc;

        gb = new GridBagLayout();
        gbc = new GridBagConstraints();
        Insets ins = new Insets(2,2,2,2);

        setLayout(gb);
        gbc.fill = GridBagConstraints.NONE;
        gbc.ipadx = 2;
        gbc.ipady = 2;
        gbc.insets = ins;

        gbc.anchor = GridBagConstraints.EAST;
        makeLabel( "Name:", gb, gbc );

        tf_Name = makeViewField( 128, gb, gbc );

        gbc.anchor = GridBagConstraints.EAST;
        makeLabel( "Command Line:", gb, gbc );

        tf_CmdLine = makeViewField( 128, gb, gbc );

        gbc.anchor = GridBagConstraints.EAST;
        makeLabel( "Archive File", gb, gbc );

        tf_Archive = makeViewField( 128, gb, gbc );

        gbc.anchor = GridBagConstraints.EAST;
        makeLabel( "Socket:", gb, gbc );

        tf_Socket = makeViewField( 10, gb, gbc );

        gbc.anchor = GridBagConstraints.EAST;
        makeLabel( "Objects:", gb, gbc );

        tf_Objects = makeViewField( 10, gb, gbc );

        gbc.anchor = GridBagConstraints.NORTHEAST;
        makeLabel( "Tasks:", gb, gbc );

        lst_Threads = makeList( gb, gbc );

        gbc.anchor = GridBagConstraints.NORTHEAST;
        makeLabel( "Output:", gb, gbc );

        ta_Output = makeViewArea( 10, 30, gb, gbc );
    }

    private void makeLabel( String txt, GridBagLayout gb, GridBagConstraints gbc )
    {
        Label lbl;

        gbc.weightx = 0.0;
        gbc.gridwidth = GridBagConstraints.RELATIVE;
        lbl = new Label( txt );
        gb.setConstraints( lbl, gbc );
        add( lbl );
    }

    private TextField makeViewField( int fieldSize, GridBagLayout gb, GridBagConstraints gbc )
    {
        TextField tf;

        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        tf = new TextField(fieldSize);
        tf.setEditable(false);
        gbc.anchor = GridBagConstraints.WEST;
        gb.setConstraints( tf, gbc );
        add( tf );
        return tf;
    }

    private TextArea makeViewArea( int rows, int cols, GridBagLayout gb, GridBagConstraints gbc )
    {
        TextArea ta;

        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        ta = new TextArea(rows, cols);
        ta.setEditable(false);
        gbc.anchor = GridBagConstraints.WEST;
        gb.setConstraints( ta, gbc );
        add( ta );
        gbc.fill = GridBagConstraints.NONE;
        return ta;
    }

    private List makeList( GridBagLayout gb, GridBagConstraints gbc )
    {
        List lst;

        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        lst = new List(7, false);
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gb.setConstraints( lst, gbc );
        add( lst );
        gbc.fill = GridBagConstraints.NONE;
        return lst;
    }

    public void onViewUpdate()
    {
        Enumeration objs;
        Object obj;

        tf_CmdLine.setText( m_CmdLine );
        tf_Name.setText( m_Name );
        tf_Archive.setText( m_PersistentStorage.getFileName() );
        tf_Socket.setText( String.valueOf(Application.getSocket()) );
        lst_Threads.clear();
        objs = getObjectManager().getAll();
        int i = 0;
        while( objs.hasMoreElements() )
        {
            i++;
            obj = objs.nextElement();
            if( obj instanceof Task )
		        addTaskList( ((Task) obj).getGlobalName() );
        }
        tf_Objects.setText( Long.toString(i) );
    }

    protected void onViewCreate()
    {
        setTitle(m_Name);
        addStandardComponents();
        addStandardMenu();
        pack();
        resize( new Dimension( 400,400 ) );
        show();
        onViewUpdate();
    }

    public void save( Archive ar )
    {
    }

    public void restore( Archive ar )
    {
    }
}
