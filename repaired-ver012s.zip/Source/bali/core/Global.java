
package bali.core;

import bali.core.GlobalAccessible;
import bali.core.Application;
import bali.core.Task;
import bali.core.Archive;
import bali.core.ObjectManager;
import bali.core.CriticalException;

import java.lang.Object;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

/*
 *
 * Global
 *
 */

public abstract class Global extends Object implements GlobalAccessible
{
    protected static final short VERSION = 1;
    // fromString Results
    protected static final String OK = "#OK";
    protected static final String NOT_APPLICABLE = "#Not Applicable";
    protected static final String UNKNOWN_CLASS = "#Unknown Class";
    protected static final String UNKNOWN_OBJECT = "#Unknown Object";
    protected static final String ILLEGAL_CLASS = "#Illegal Class:";
    protected static final String NOT_YET = "#Not Implemented Yet.";

    protected boolean  m_PostponedWrite;
    protected long    m_LastWriteAccessTime;
    protected long    m_LastReadAccessTime;
    protected short   m_Error;
    protected Object  m_Parent;
    protected Task    m_ParentTask;

    protected long    m_FilePointer;
    protected String  m_Name;
    protected long    m_PassWrite;
    protected boolean m_Persistent;
    protected int     m_MaxLen;

    protected Global() throws CriticalException
    {
        if( ! (this instanceof ObjectManager) )
            throw new CriticalException( "Global() constructor may only be used by ObjectManager." );

    }

    public Global( Object parent, String name )
        throws IOException, CriticalException
    {
        // Constructor of the object
        stdInit( parent, name);
    }

    public Global( Object parent, String name, boolean persist )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        // Constructor of the object
        stdInit( parent, name);
        m_Persistent = persist;
    }

    public Global( Object parent, String name, boolean persist, boolean postponed )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        // Constructor of the object
        stdInit( parent, name);
        m_Persistent = persist;
        m_PostponedWrite = postponed;
    }

    protected void stdInit(Object parent, String name)
        throws IOException, CriticalException
    {
        m_Parent = parent;
        m_Name = name;

        if( this instanceof ObjectManager )
        {
            ( (ObjectManager) this).add( parent, this, name );
        }
        else if( parent == null || parent instanceof Global || parent instanceof Task || parent instanceof Application )
        {
            ObjectManager om = Application.getApp().getObjectManager();
            om.add( parent, this, name );
            m_ParentTask = getParentTask(parent);
        }
        else
        {
            CriticalException e = new CriticalException( "Invalid Parent Class in use of Global Access System." );
            throw( e );
        }

        m_FilePointer = -1;
        m_LastWriteAccessTime = 0;
        m_LastReadAccessTime = 0;
        m_Error = 0;
        m_PostponedWrite = false;
        m_PassWrite = 0;
        m_Persistent = true;
    }

    public boolean isPersistent()
    {
        return m_Persistent;
    }

    private Task getParentTask( Object p )
    {
        if( p instanceof Task )
            return (Task) p;
        else
        {
            if( p instanceof Global )
                return getParentTask(( (Global) p).getParent() );
            else
                return null;
        }
    }

    public void finalize() throws Throwable
    {
        // Destroys the object.
        Application.getObjectManager().delete(this);
    	super.finalize();
    }

    public String getLocalName()
    {
        return m_Name;
    }

    public String getGlobalName()
    {
        String str;

        str = "";
        if( m_Parent != null )
        {
            if( m_Parent instanceof Global )
                str = ((Global) m_Parent).getGlobalName();
            else if( m_Parent instanceof Task )
                str = ((Task) m_Parent).getGlobalName();
            else if( m_Parent instanceof Application )
                str = ((Application) m_Parent).getGlobalName();
            return str + "." + m_Name;
        }
        else
            return m_Name;

    }

    public String getGlobalObject( boolean verbose )
    {
        String str;

        str = toString();
        if( verbose )
        {
            str = str + ", Error = " + Long.toString(m_Error);
            str = str + ", LastReadAccessTime = " + Long.toString(m_LastReadAccessTime);
            str = str + ", LastWriteAccessTime = " + Long.toString(m_LastWriteAccessTime);
        }
        return str;
    }

    public Object getParent()
    {
        return m_Parent;
    }

    long getAccess( boolean writing )
    {
        if( writing )
            return m_LastWriteAccessTime;
        else
            return m_LastReadAccessTime ;
    }

    short getError()
    {
        return m_Error;
    }

    long getFilePointer()
    {
        return m_FilePointer;
    }

    void setFilePointer( long pos )
    {
        m_FilePointer = pos;
    }

    void notifyChange()
    {
        ObjectManager om = Application.getApp().getObjectManager();
        om.notifyChange( this );
    }

    protected void set_Overhead( boolean changed ) throws IOException
    {
        m_LastWriteAccessTime = System.currentTimeMillis();
        if( changed )
        {
            Archive ar;

            ar = Application.getArchive();
            if( ar != null )
            {
                // If Archive been initilized
                notifyChange();
                ar.objectChanged( this, m_ParentTask, m_PostponedWrite );
            }
        }
    }

    protected void get_Overhead()
    {
        m_LastReadAccessTime = System.currentTimeMillis();
    }

    void restore( Archive ar, short version )
        throws IOException, CriticalException
    {
        // At Entry the filepointer is at the Value field of the record.
        String str;
        if( version == 1 )
        {
            str = ar.m_File.readUTF();
            fromString(str);
        }
        else
            throw new CriticalException( "Program older than Archive." );
    }

    void save( Archive ar ) throws IOException
    {
        ar.writeUTF( this.toString() );  // Save Data
    }

    public void changeNotification( Object obj )
    {
        // Called by the framework when a subscribed
        // value has changed
        // Default: Do nothing.

    }

    public void setPassWrite( long pass )
    {
        m_PassWrite = pass;
    }

    public short getVersion()
    {
        return VERSION;
    }

}
