
package bali.core;

import bali.core.Global;

import java.io.IOException;
import java.util.NoSuchElementException;

/*
 *
 * GlobalInterface
 *
 */
public interface GlobalAccessible
{
    String getGlobalName();
    String getGlobalObject( boolean verbose );
    void changeNotification( Object obj ) throws Throwable;
    String toString();
    String fromString( String textObject );
}

