
package bali.core;

import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

import java.lang.Object;
import java.io.RandomAccessFile;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import jgl.HashMap;
import jgl.HashMapIterator;
import jgl.Pair;
/*
 *
 * Archive
 *
 */

public final class Archive extends Task
{
    public static final long AT_BEGINNING = -2;
    public static final long AT_END = -3;

    RandomAccessFile m_File;
    GlobalString m_FileName;
    private boolean m_Initilized;
    private HashMap stdUpdates;
    private HashMap taskUpdates;
    private HashMap fileObjects;

    Archive(Application parent, String taskname )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        super( parent, taskname );

        m_File = null;
        m_Initilized = false;
        m_FileName = new GlobalString( this, "FileName" );
        setCycle( 30000 );  //Update every 30 seconds...
        setPriority( BACKGROUND );
        stdUpdates = new HashMap( false );
        taskUpdates = new HashMap( true );
    }

    public void warmStart()
        throws IllegalArgumentException
    {
        setPriority( Task.BACKGROUND );
    }

    public void coldStart()
        throws IllegalArgumentException
    {
        setPriority( Task.BACKGROUND );
    }

    public void coolStart()
        throws IllegalArgumentException
    {
        setPriority( Task.BACKGROUND );
    }

    public boolean onTimer()
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        // Saves all objects that has been updated and placed in
        // the Standard Update HashMap (stdUpdates).

        Enumeration objects;
        Object obj;

        objects = stdUpdates.elements();
        while( objects.hasMoreElements() )
        {
            obj = objects.nextElement();
            if( obj == null )
                throw new CriticalException( "Internal Error in Archive.onTimer(): null object retrieved." );
            if( obj instanceof Global )
                save((Global)obj);
            else if( obj instanceof Task )
                save( (Task) obj);
            else if( obj instanceof Application )
                save( (Application) obj);
            else
                throw new CriticalException( "Internal Error in Archive.onTimer(): A non-compatible object retrieved." );
            stdUpdates.remove( obj );
        }
        flush();
        return true;
    }

    public boolean openNewArchive( String fileName )
        throws CriticalException, IOException, ObjectReadOnlyException
    {
        File oldFile= new File( fileName );
        File bakFile= new File( fileName + ".backup" );

        if( oldFile.isFile() )
        {
            if( bakFile.isFile() )
                if( ! bakFile.delete() )
                    throw new CriticalException( "Archive.openNewArchive(). Existing backup file could not be removed." );
            if( ! oldFile.renameTo( bakFile ) )
                if( ! oldFile.delete() )
                    throw new CriticalException( "Archive.openNewArchive(). Existing file could not be removed." );
        }

        m_FileName.set( fileName );
        try
        {
            m_File = new RandomAccessFile( fileName, "rw" );
            m_Initilized = true;
        }
        catch( IOException e )
        {
            reporter.exception( "Archive unable to open file " + fileName + ".", e );
        }
        return true;
    }

    public boolean openExistingArchive( String fileName )
        throws CriticalException, IOException, ObjectReadOnlyException
    {
        m_FileName.set( fileName );
        try
        {
            m_File = new RandomAccessFile( fileName, "rw" );
            m_Initilized = true;
        }
        catch( IOException e )
        {
            Application.getApp().getReporter().exception( "Archive unable to open file " + fileName + ".", e );
        }
        return true;
    }

    public void closeArchive()
        throws CriticalException, IOException, ObjectReadOnlyException
    {
        m_FileName.set( null );
        m_File.close();
    }

    public long getFilePointer()
    {
        long retVal;

        retVal = -1;
        try
        {
            if( m_Initilized )
                retVal = m_File.getFilePointer();
        } catch( IOException e )
        {
            Application.getReporter().exception( "Archive.getFilePointer()", e );
        }
        return retVal;
    }

    public void flush()
        throws CriticalException, ObjectReadOnlyException
    {
        // Make sure the data has actually been
        // written to disk.
        try
        {
            m_File.close();
            openExistingArchive( m_FileName.get() );
        } catch( IOException e )
        {
            Application.getReporter().exception( "IOException in Archive.flush()", e );
        }
    }

    public void setFilePointer( long pos )
    {
        if( m_Initilized )
        {
            try
            {
                if( pos == AT_BEGINNING )
                    m_File.seek(0L);
                else if( pos == AT_END )
                    m_File.seek(m_File.length());
                else
                    m_File.seek(pos);
            } catch( IOException e )
            {
                Application.getReporter().exception( "Archive.setFilePointer()", e );
            }
        }
    }

    public String getFileName()
    {
        return m_FileName.get();
    }

    public void changeNotification( Object obj )
	    throws IOException
    {
        Task idleTask;

        idleTask = (Task) obj;
        if( idleTask.m_Busy.get() )
        {
            // If Task starts and all data has not been
            // saved yet, ????
        }
        else
        {
            // Task has been stopped and all changed objects
            // should be saved.

            Object data;
            HashMapIterator hmi = taskUpdates.find( obj );

            while( hmi.hasMoreElements() )
            {
                data = hmi.nextElement();
                if( data instanceof Global )
                     ((Global) data).save(this);
                if( data instanceof Task )
                     ((Task) data).save(this);
                if( data instanceof Application )
                     ((Application) data).save(this);
            }
        }
    }

    public String fromString( String str )
    {
        return "";
    }

    public String toString()
    {
        return "";
    }

    public void objectChanged( Object obj, Object parent, boolean lateWrite )
    {
        // Called when a object has been modified and should
        // be updated.
        // If the parent is a Task and lateWrite is true, the request
        // will be postponed until the Task is no longer busy.

        if( parent instanceof Task && lateWrite )
        {
            Pair p = new Pair( parent, obj );
            taskUpdates.add( p );
            Application.getObjectManager().subscribe( this, ((Task) parent).m_Busy );
        }
        else
        {
            Pair p = new Pair( obj, parent );
            stdUpdates.add(p);
        }
    }

    public void saveAllCreatedObjects()
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        // Calls the ObjectManager to get all Global references
        // Check if they are persistent and save them to Archive.

        Enumeration all;
        Object obj;
        ObjectManager om = Application.getObjectManager();

        all = om.getAll();
        while( all.hasMoreElements() )
        {
            obj = all.nextElement();
            if( obj == null )
                throw new CriticalException( "Internal Error in Archive.saveAllCreatedObjects(): null object retrieved." );
            if( obj instanceof Global )
                save((Global)obj);
            else if( obj instanceof Task )
                save( (Task) obj);
            else if( obj instanceof Application )
                save( (Application) obj);
            else
                throw new CriticalException( "Internal Error in Archive.saveAllCreatedObjects(): A non-compatible object retrieved." );
        }
        flush();
    }

    void save( Global obj )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        String str;
        long pos1;
        long pos2;

        if( obj.isPersistent() )
        {
            if( obj.m_FilePointer == -1 )  // First Time
            {
                setFilePointer( Archive.AT_END ); //Append to File.
                pos1 = getFilePointer();         // Save Field Length position
                m_File.skipBytes(2);             // For Field Length to be written
                m_File.writeShort(obj.getVersion());    // Write Version
                m_File.writeUTF( obj.getGlobalName() ); // Write Name
                str = obj.getClass().toString();
                m_File.writeUTF( str );  //Write ClassName
                obj.setFilePointer(getFilePointer());    // Remember Data position
                obj.save( this );
                pos2 = getFilePointer();         // Reposition to Field Length
                setFilePointer( pos1 );          // Write Field Length
                m_File.writeShort( (short) (pos2 - pos1) );
            }
            else
            {
                setFilePointer( obj.getFilePointer() );
                obj.save( this );
            }
        }
    }

    void save( Task obj )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        long pos1;
        long pos2;

        if( obj.isPersistent() )
        {
            if( obj.m_FilePointer == -1 )  // First Time
            {
                setFilePointer( Archive.AT_END ); //Append to File.
                pos1 = getFilePointer();         // Save Field Length position
                m_File.skipBytes( 2 );           // For Field Length to be written
                m_File.writeShort(1);            // Write Version
                m_File.writeUTF( obj.getGlobalName() ); // Write Name
                m_File.writeUTF( obj.getClass().toString() );  //Write ClassName
                obj.setFilePointer(getFilePointer());  // Remember Data position
                obj.save( this );
                pos2 = getFilePointer();         // Reposition to Field Length
                setFilePointer( pos1 );          // Write Field Length
                m_File.writeShort( (short) (pos2 - pos1) );
            }
            else
            {
                setFilePointer( obj.getFilePointer() );
                obj.save( this );
            }
        }
    }

    void save( Application obj )
        throws IOException, CriticalException, ObjectReadOnlyException
    {
        long pos1;
        long pos2;

        if( obj.isPersistent() )
        {
            if( obj.m_FilePointer == -1 )  // First Time
            {
                setFilePointer( Archive.AT_END ); //Append to File.
                pos1 = getFilePointer();         // Save Field Length position
                m_File.skipBytes( 2 );           // For Field Length to be written
                m_File.writeShort(1);            // Write Version
                m_File.writeUTF( obj.getGlobalName() ); // Write Name
                m_File.writeUTF( obj.getClass().toString() );  //Write ClassName
                obj.setFilePointer(getFilePointer());   // Remember Data position
                obj.save( this );
                pos2 = getFilePointer();         // Reposition to Field Length
                setFilePointer( pos1 );          // Write Field Length
                m_File.writeShort( (short) (pos2 - pos1) );
            }
            else
            {
                setFilePointer( obj.getFilePointer() );
                obj.save( this );
            }
        }
    }

    public void restoreAllCreatedObjects()
    {
        // Scans the Archive, for each object found, get it from the
        // ObjectManager, and restores it previous state.
        // If Object doesn't exist, remove it from Archive.
    }

    public void writeUTF( String str )
        throws IOException
    {
        m_File.writeUTF( str );
    }

    public String readUTF()
        throws IOException
    {
        return m_File.readUTF();
    }
}
