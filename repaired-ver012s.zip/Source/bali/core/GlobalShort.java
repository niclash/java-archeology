
package bali.core;

import bali.core.Global;
import bali.core.Archive;
import bali.core.Application;
import bali.core.ObjectManager;
import bali.core.Task;
import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

import java.io.IOException;
import java.lang.Boolean;

/*
 *
 * GlobalShort
 *
 */

public class GlobalShort extends Global
{
    short m_Value;

    public GlobalShort(Object parent, String Name)
        throws IOException, CriticalException
    {
        super(parent, Name);

        m_MaxLen = 10;
    }

    public short get() throws NumberFormatException
    {
        super.get_Overhead();
        return m_Value;
    }

    public void set( short value, long pass  )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == pass || m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public void set( short value )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public String toString()
    {
        StringBuffer str;

        str = new StringBuffer((new Integer(m_Value)).toString());
        try
        {
            str.setLength(m_MaxLen);
        } catch( StringIndexOutOfBoundsException e)
        {
            Application.getReporter().exception( "Internal Error!\nGlobalShort.toString()", e );
        }
        return str.toString();
    }

    public String fromString( String str )
    {
        int tmp;

        tmp = (Integer.valueOf( str.trim() )).intValue();
        tmp = tmp > 32767? 32767 : tmp;
        tmp = tmp < -32768 ? -32768 : tmp;
        m_Value = (short) tmp;
        return Global.OK;
    }

}

