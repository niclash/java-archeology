
package bali.core;

import bali.core.Global;
import bali.core.Archive;
import bali.core.Application;
import bali.core.ObjectManager;
import bali.core.Task;
import bali.core.CriticalException;
import bali.core.ObjectReadOnlyException;

import java.io.IOException;
import java.lang.Boolean;

/*
 *
 * GlobalInt
 *
 */

public class GlobalInt extends Global
{
    int m_Value;

    public GlobalInt(Object parent, String Name)
        throws IOException, CriticalException
    {
        super(parent, Name);
        m_MaxLen = ((new Integer(Integer.MIN_VALUE)).toString()).length()+3;
    }

    public int get() throws NumberFormatException
    {
        super.get_Overhead();
        return m_Value;
    }

    public void set( int value, long pass  )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == pass || m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public void set( int value )
        throws IOException, ObjectReadOnlyException
    {
        boolean notify;

        if( m_PassWrite == 0 )
        {
            notify = m_Value != value;
            super.set_Overhead(notify);
            m_Value = value;
        }
        else
        {
            ObjectReadOnlyException e = new ObjectReadOnlyException( "Object Write Protect violation." );
            throw e;
        }
    }

    public String toString()
    {
        StringBuffer str;

        str = new StringBuffer((new Integer(m_Value)).toString());
        try
        {
            str.setLength(m_MaxLen);
        } catch( StringIndexOutOfBoundsException e)
        {
            Application.getReporter().exception( "Internal Error!\nGlobalInt.toString()", e );
        }
        return str.toString();
    }

    public String fromString( String str )
    {
        m_Value = (Integer.valueOf( str.trim() )).intValue();
        return Global.OK;
    }

}

